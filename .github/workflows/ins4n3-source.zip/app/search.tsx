import { Ionicons } from "@expo/vector-icons";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useCallback, useEffect, useRef, useState } from "react";
import { ActivityIndicator, FlatList, Pressable, Text, View, type ListRenderItem } from "react-native";
import { C, EmptyState, ErrorBanner, MoviePosterCard, SearchField, TopBar } from "@/components/moviebox-ui";
import { searchMovies } from "@/lib/archive";
import { useMovieBox } from "@/lib/moviebox/context";
import type { Movie } from "@/lib/moviebox/types";

export default function SearchScreen() {
  const router = useRouter();
  const params = useLocalSearchParams<{ q?: string }>();
  const { isFavorite, toggleFavorite } = useMovieBox();
  const [query, setQuery] = useState(params.q ?? "");
  const [submitted, setSubmitted] = useState(params.q ?? "");
  const [movies, setMovies] = useState<Movie[]>([]);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const requestId = useRef(0);

  const runSearch = useCallback(async (term: string, nextPage: number, reset: boolean) => {
    if (!term.trim()) { setMovies([]); setSubmitted(""); setLoading(false); return; }
    const request = ++requestId.current;
    setLoading(true); setError(""); setSubmitted(term.trim());
    try {
      const result = await searchMovies({ title: term.trim(), page: nextPage, rows: 30 });
      if (request !== requestId.current) return;
      setMovies((current) => {
        const base = reset ? [] : current;
        const existing = new Set(base.map((movie) => movie.identifier));
        return [...base, ...result.movies.filter((movie) => !existing.has(movie.identifier))];
      });
      setPage(nextPage);
      setHasMore(nextPage * 30 < result.total && result.movies.length > 0);
    } catch (err) { if (request === requestId.current) setError(err instanceof Error ? err.message : "Search failed. Check your connection."); }
    finally { if (request === requestId.current) setLoading(false); }
  }, []);

  useEffect(() => {
    if (!params.q) return;
    const timer = setTimeout(() => { setQuery(params.q!); void runSearch(params.q!, 1, true); }, 0);
    return () => clearTimeout(timer);
  }, [params.q, runSearch]);
  const renderItem: ListRenderItem<Movie> = ({ item }) => <MoviePosterCard movie={item} onPress={() => router.push({ pathname: "/movie/[identifier]", params: { identifier: item.identifier } })} favorite={isFavorite(item.identifier)} onToggleFavorite={() => void toggleFavorite(item)} />;
  const footer = <View style={{ paddingHorizontal: 20 }}>{error ? <ErrorBanner message={error} onRetry={() => void runSearch(submitted || query, page, movies.length === 0)} /> : null}{loading ? <ActivityIndicator color={C.cyan} style={{ marginVertical: 20 }} /> : null}{!loading && submitted && !movies.length && !error ? <EmptyState icon="search-outline" title="No titles found" body="Try another title. INS4N3 only shows items with explicit public-domain rights information." /> : null}{hasMore && movies.length && !loading ? <Pressable onPress={() => void runSearch(submitted, page + 1, false)} style={{ padding: 20, alignItems: "center" }}><Text style={{ color: C.cyan, fontWeight: "800", fontSize: 12 }}>LOAD MORE RESULTS</Text></Pressable> : null}</View>;
  return <FlatList data={movies} keyExtractor={(item) => item.identifier} renderItem={renderItem} numColumns={2} columnWrapperStyle={{ gap: 13, paddingHorizontal: 20 }} contentContainerStyle={{ paddingBottom: 20 }} ListHeaderComponent={<View style={{ paddingTop: 7 }}><TopBar title="Search" subtitle="PUBLIC-DOMAIN TITLES" onBack={() => router.back()} right={<Pressable onPress={() => setQuery("")} style={{ padding: 8 }}><Ionicons name="close" size={20} color={C.muted} /></Pressable>} /><View style={{ paddingHorizontal: 20, paddingTop: 13 }}><SearchField value={query} onChangeText={setQuery} onSubmitEditing={() => void runSearch(query, 1, true)} autoFocus={!params.q} /><Text style={{ color: C.muted, fontSize: 11, marginTop: 12 }}>{submitted ? `Results for “${submitted}”` : "Search the Archive.org public-domain collection."}</Text></View></View>} ListFooterComponent={footer} onEndReachedThreshold={0.4} onEndReached={() => { if (hasMore && !loading && !error) void runSearch(submitted, page + 1, false); }} showsVerticalScrollIndicator={false} />;
}
