import { Ionicons } from "@expo/vector-icons";
import { Image } from "expo-image";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useCallback, useEffect, useMemo, useState } from "react";
import { ActivityIndicator, Alert, Modal, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { C, EmptyState, NeonButton, Page, TopBar } from "@/components/moviebox-ui";
import { formatBytes, getMovie, getMovieMetadata, listMovieQualities, metadataRuntime, metadataSize, posterUrl } from "@/lib/archive";
import { useMovieBox } from "@/lib/moviebox/context";
import type { Movie, MovieQuality } from "@/lib/moviebox/types";

export default function MovieDetailScreen() {
  const { identifier } = useLocalSearchParams<{ identifier: string }>();
  const router = useRouter();
  const { isFavorite, toggleFavorite, startDownload } = useMovieBox();
  const [movie, setMovie] = useState<Movie | null>(null);
  const [files, setFiles] = useState<MovieQuality[]>([]);
  const [runtime, setRuntime] = useState<string>();
  const [totalSize, setTotalSize] = useState<string>();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [sheet, setSheet] = useState<"watch" | "download" | null>(null);
  const [selected, setSelected] = useState(0);
  const [actionLoading, setActionLoading] = useState(false);

  const refresh = useCallback(async () => {
    setLoading(true); setError("");
    try {
      const [item, meta] = await Promise.all([getMovie(identifier), getMovieMetadata(identifier)]);
      const qualities = listMovieQualities(identifier, meta.files ?? []);
      setMovie(item); setFiles(qualities); setRuntime(metadataRuntime(meta) ?? item.runtime); setTotalSize(metadataSize(meta) ?? item.size);
      setSelected(0);
    } catch (err) { setError(err instanceof Error ? err.message : "Could not load movie details."); }
    finally { setLoading(false); }
  }, [identifier]);
  useEffect(() => {
    if (!identifier) return;
    const timer = setTimeout(() => { void refresh(); }, 0);
    return () => clearTimeout(timer);
  }, [identifier, refresh]);

  const currentFavorite = useMemo(() => movie ? isFavorite(movie.identifier) : false, [movie, isFavorite]);
  const begin = async () => {
    if (!movie || !files[selected]) return;
    const quality = files[selected];
    setSheet(null);
    if (sheet === "watch") {
      router.push({ pathname: "/player", params: { uri: quality.downloadUrl, title: movie.title, movie: JSON.stringify(movie) } });
      return;
    }
    setActionLoading(true);
    try {
      await startDownload(movie, quality);
      Alert.alert("Download started", `${movie.title} is downloading in the background. Track it in My Downloads.`);
    } catch (err) {
      Alert.alert("Could not start download", err instanceof Error ? err.message : "Check your connection and available storage.");
    } finally { setActionLoading(false); }
  };

  if (loading) return <Page><TopBar title="Movie details" onBack={() => router.back()} /><ActivityIndicator color={C.cyan} style={{ flex: 1 }} /></Page>;
  if (error || !movie) return <Page><TopBar title="Movie details" onBack={() => router.back()} /><EmptyState icon="cloud-offline-outline" title="Movie unavailable" body={error || "The Archive.org item could not be found."} action="Retry" onAction={() => void refresh()} /></Page>;

  const actions = [{ title: "Watch", icon: "play" as const, kind: "watch" as const }, { title: "Download", icon: "download" as const, kind: "download" as const }];
  return <Page>
    <TopBar title="Movie details" onBack={() => router.back()} right={<Pressable onPress={() => void toggleFavorite(movie)} style={styles.topHeart}><Ionicons name={currentFavorite ? "heart" : "heart-outline"} color={currentFavorite ? C.magenta : C.text} size={21} /></Pressable>} />
    <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 38 }}>
      <View style={styles.heroFrame}><Image source={{ uri: posterUrl(movie.identifier) }} contentFit="cover" transition={250} style={StyleSheet.absoluteFill} /><View style={styles.heroFade} /><View style={styles.heroBadge}><Ionicons name="shield-checkmark" color={C.green} size={13} /><Text style={styles.heroBadgeText}>PUBLIC DOMAIN</Text></View></View>
      <View style={{ paddingHorizontal: 22, marginTop: 20 }}>
        <Text style={styles.title}>{movie.title}</Text>
        <View style={styles.metaRow}><Text style={styles.meta}>{movie.year || "Year unknown"}</Text><Text style={styles.metaDot}>•</Text><Text style={styles.meta}>{runtime || "Runtime unavailable"}</Text><Text style={styles.metaDot}>•</Text><Text style={styles.meta}>{totalSize || "Size unavailable"}</Text></View>
        <Text style={styles.description}>{movie.description?.replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim() || "No description was provided for this Archive.org item."}</Text>
        <View style={styles.legalNote}><Ionicons name="information-circle-outline" size={17} color={C.cyan} /><Text style={styles.legalText}>This item declares a public-domain mark or dedication. Confirm usage rights for your jurisdiction and intended use.</Text></View>
        <View style={{ flexDirection: "row", gap: 11, marginTop: 23 }}>
          {actions.map((action) => <NeonButton key={action.kind} title={action.title} icon={action.icon} onPress={() => { setSheet(action.kind); setSelected(0); }} disabled={!files.length || actionLoading} secondary={action.kind === "download"} style={{ flex: 1 }} />)}
        </View>
        {actionLoading ? <ActivityIndicator color={C.cyan} style={{ marginTop: 14 }} /> : null}
        <Text style={styles.smallNote}>{files.length ? `${files.length} playable video quality${files.length === 1 ? "" : "ies"} available` : "No supported video files were found."}</Text>
      </View>
    </ScrollView>
    <Modal visible={!!sheet} transparent animationType="slide" onRequestClose={() => setSheet(null)}>
      <Pressable style={styles.scrim} onPress={() => setSheet(null)} />
      <View style={styles.sheet}>
        <View style={styles.grabber} />
        <View style={styles.sheetHeading}><View><Text style={styles.sheetTitle}>{sheet === "watch" ? "Choose a stream" : "Download quality"}</Text><Text style={styles.sheetSub}>Video files from the Internet Archive item</Text></View><Pressable onPress={() => setSheet(null)} style={styles.close}><Ionicons name="close" size={20} color={C.muted} /></Pressable></View>
        {!files.length ? <EmptyState icon="videocam-off-outline" title="No playable files" body="This item does not contain a supported MP4, OGV, MKV, AVI, H.264, or 512kb video file." /> : <ScrollView style={{ maxHeight: 390 }} showsVerticalScrollIndicator={false}>
          {files.map((file, index) => <Pressable key={file.name} onPress={() => setSelected(index)} style={[styles.quality, selected === index && styles.qualitySelected]}>
            <View style={[styles.radio, selected === index && styles.radioSelected]}>{selected === index ? <View style={styles.radioDot} /> : null}</View>
            <View style={{ flex: 1 }}><View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}><Text style={styles.qualityLabel}>{file.label}</Text>{index === 0 ? <Text style={styles.best}>BEST</Text> : null}</View><Text numberOfLines={1} style={styles.fileName}>{file.format || file.name.split(".").pop()?.toUpperCase() || "VIDEO"} · {file.name}</Text></View>
            <Text style={styles.fileSize}>{formatBytes(file.bytes)}</Text>
          </Pressable>)}
        </ScrollView>}
        {files.length ? <NeonButton title={sheet === "watch" ? "Watch this quality" : "Start download"} icon={sheet === "watch" ? "play" : "download"} onPress={() => void begin()} style={{ marginTop: 14 }} /> : null}
      </View>
    </Modal>
  </Page>;
}

const styles = StyleSheet.create({
  topHeart: { width: 40, height: 40, borderRadius: 14, alignItems: "center", justifyContent: "center", backgroundColor: C.card, borderWidth: 1, borderColor: C.line },
  heroFrame: { height: 345, marginHorizontal: 18, borderRadius: 20, marginTop: 9, overflow: "hidden", backgroundColor: C.card, borderWidth: 1, borderColor: "#232337" },
  heroFade: { position: "absolute", top: 0, right: 0, bottom: 0, left: 0, backgroundColor: "rgba(5,5,10,0.12)" },
  heroBadge: { position: "absolute", bottom: 14, left: 14, flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: "rgba(5,5,10,0.88)", borderRadius: 9, paddingHorizontal: 11, paddingVertical: 7, borderWidth: 1, borderColor: "#264738" },
  heroBadgeText: { color: C.green, fontSize: 9, fontWeight: "900", letterSpacing: 1 },
  title: { color: C.text, fontSize: 27, fontWeight: "800", lineHeight: 33 },
  metaRow: { flexDirection: "row", alignItems: "center", gap: 8, marginTop: 9, flexWrap: "wrap" },
  meta: { color: C.muted, fontSize: 12, fontWeight: "600" },
  metaDot: { color: C.cyan, fontSize: 12 },
  description: { color: "#B8B8C8", fontSize: 14, lineHeight: 21, marginTop: 19 },
  legalNote: { flexDirection: "row", gap: 9, padding: 12, borderRadius: 13, backgroundColor: "#0B1720", borderWidth: 1, borderColor: "#18313D", marginTop: 18 },
  legalText: { color: C.muted, flex: 1, fontSize: 11, lineHeight: 16 },
  smallNote: { color: C.dim, textAlign: "center", fontSize: 10, marginTop: 13 },
  scrim: { position: "absolute", top: 0, right: 0, bottom: 0, left: 0, backgroundColor: "rgba(0,0,0,0.66)" },
  sheet: { position: "absolute", bottom: 0, left: 0, right: 0, backgroundColor: "#0B0B14", borderTopLeftRadius: 27, borderTopRightRadius: 27, borderTopWidth: 1, borderColor: "#303045", paddingTop: 10, paddingHorizontal: 20, paddingBottom: 32, maxHeight: "82%" },
  grabber: { width: 42, height: 4, borderRadius: 4, backgroundColor: "#49495C", alignSelf: "center", marginBottom: 20 },
  sheetHeading: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 15 },
  sheetTitle: { color: C.text, fontSize: 19, fontWeight: "800" },
  sheetSub: { color: C.muted, fontSize: 11, marginTop: 4 },
  close: { width: 34, height: 34, borderRadius: 11, backgroundColor: C.card, alignItems: "center", justifyContent: "center" },
  quality: { flexDirection: "row", alignItems: "center", gap: 11, padding: 13, borderRadius: 14, borderWidth: 1, borderColor: C.line, backgroundColor: C.card, marginBottom: 9 },
  qualitySelected: { borderColor: C.cyan, backgroundColor: "#0A1820" },
  radio: { width: 19, height: 19, borderRadius: 10, borderWidth: 1.5, borderColor: C.dim, alignItems: "center", justifyContent: "center" },
  radioSelected: { borderColor: C.cyan },
  radioDot: { width: 9, height: 9, borderRadius: 5, backgroundColor: C.cyan },
  qualityLabel: { color: C.text, fontSize: 13, fontWeight: "800" },
  best: { color: C.bg, backgroundColor: C.magenta, fontSize: 8, fontWeight: "900", letterSpacing: 0.8, borderRadius: 5, paddingHorizontal: 6, paddingVertical: 3 },
  fileName: { color: C.muted, fontSize: 10, marginTop: 5, maxWidth: 190 },
  fileSize: { color: C.cyan, fontSize: 11, fontWeight: "800" },
} as const);
