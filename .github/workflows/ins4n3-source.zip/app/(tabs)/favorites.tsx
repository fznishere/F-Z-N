import { useRouter } from "expo-router";
import { FlatList, Text, View, type ListRenderItem } from "react-native";
import { EmptyState, MoviePosterCard, TopBar } from "@/components/moviebox-ui";
import { useMovieBox } from "@/lib/moviebox/context";
import type { Movie } from "@/lib/moviebox/types";

export default function FavoritesScreen() {
  const router = useRouter();
  const { favorites, toggleFavorite } = useMovieBox();
  const renderItem: ListRenderItem<Movie> = ({ item }) => <MoviePosterCard movie={item} favorite onToggleFavorite={() => void toggleFavorite(item)} onPress={() => router.push({ pathname: "/movie/[identifier]", params: { identifier: item.identifier } })} />;
  return <FlatList data={favorites} keyExtractor={(item) => item.identifier} renderItem={renderItem} numColumns={2} columnWrapperStyle={{ gap: 13, paddingHorizontal: 20 }} contentContainerStyle={{ paddingBottom: 32 }} ListHeaderComponent={<View style={{ paddingTop: 8, paddingHorizontal: 20 }}><TopBar title="Favourites" subtitle="YOUR SAVED CINEMA" /><Text style={{ color: "#9292A5", fontSize: 12, marginTop: 7, marginBottom: 18 }}>Saved on this device. No account needed.</Text></View>} ListEmptyComponent={<EmptyState icon="heart-outline" title="Your watchlist is waiting" body="Tap the heart on any film to keep it close." />} showsVerticalScrollIndicator={false} />;
}
