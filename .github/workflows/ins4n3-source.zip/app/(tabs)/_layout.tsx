import { Ionicons } from "@expo/vector-icons";
import { Tabs } from "expo-router";
import { Platform } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { C } from "@/components/moviebox-ui";

export default function TabLayout() {
  const insets = useSafeAreaInsets();
  const bottomPadding = Platform.OS === "web" ? 8 : Math.max(insets.bottom, 7);
  return <Tabs screenOptions={{ headerShown: false, tabBarActiveTintColor: C.cyan, tabBarInactiveTintColor: C.dim, tabBarLabelStyle: { fontSize: 9, fontWeight: "700", marginTop: -1 }, tabBarStyle: { backgroundColor: "#0A0A12", borderTopColor: "#252536", borderTopWidth: 1, height: 55 + bottomPadding, paddingTop: 7, paddingBottom: bottomPadding }, tabBarItemStyle: { paddingTop: 1 } }}>
    <Tabs.Screen name="index" options={{ title: "Home", tabBarIcon: ({ color, size }) => <Ionicons name="film-outline" size={size} color={color} /> }} />
    <Tabs.Screen name="favorites" options={{ title: "Favourites", tabBarIcon: ({ color, size }) => <Ionicons name="heart-outline" size={size} color={color} /> }} />
    <Tabs.Screen name="downloads" options={{ title: "Downloads", tabBarIcon: ({ color, size }) => <Ionicons name="cloud-download-outline" size={size} color={color} /> }} />
    <Tabs.Screen name="settings" options={{ title: "Settings", tabBarIcon: ({ color, size }) => <Ionicons name="settings-outline" size={size} color={color} /> }} />
  </Tabs>;
}
