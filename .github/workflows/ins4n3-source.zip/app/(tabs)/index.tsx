import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { useCallback, useEffect, useRef, useState } from "react";
import { ActivityIndicator, FlatList, Pressable, ScrollView, Text, View, type ListRenderItem } from "react-native";
import { CategoryChip, C, EmptyState, ErrorBanner, MoviePosterCard, PoweredFooter, SearchField, SectionTitle, TopBar } from "@/components/moviebox-ui";
import { searchMovies } from "@/lib/archive";
import { useMovieBox } from "@/lib/moviebox/context";
import type { Movie, MovieCategory } from "@/lib/moviebox/types";

const categories: MovieCategory[] = ["All", "Classic", "Sci-Fi", "Horror", "Comedy", "Drama", "Animation", "Documentary"];

export default function HomeScreen() {
  const router = useRouter();
  const { isFavorite, toggleFavorite } = useMovieBox();
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<MovieCategory>("All");
  const [movies, setMovies] = useState<Movie[]>([]);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState("");
  const requestId = useRef(0);

  const loadPage = useCallback(async (nextPage: number, reset = false) => {
    const request = ++requestId.current;
    setLoading(true);
    setError("");
    try {
      const result = await searchMovies({ page: nextPage, rows: 30, category });
      if (request !== requestId.current) return;
      setMovies((current) => {
        const base = reset ? [] : current;
        const known = new Set(base.map((movie) => movie.identifier));
        return [...base, ...result.movies.filter((movie) => !known.has(movie.identifier))];
      });
      setPage(nextPage);
      setHasMore(nextPage * 30 < result.total && result.movies.length > 0);
    } catch (err) {
      if (request !== requestId.current) return;
      setError(err instanceof Error ? err.message : "Could not load Archive.org films. Check your connection and retry.");
    } finally {
      if (request === requestId.current) {
        setLoading(false);
        setRefreshing(false);
      }
    }
  }, [category]);

  useEffect(() => {
    const timer = setTimeout(() => {
      setMovies([]);
      setPage(1);
      setHasMore(true);
      void loadPage(1, true);
    }, 0);
    return () => clearTimeout(timer);
  }, [loadPage]);
  const submitSearch = () => { if (query.trim()) router.push({ pathname: "/search", params: { q: query.trim() } }); };
  const openMovie = (movie: Movie) => router.push({ pathname: "/movie/[identifier]", params: { identifier: movie.identifier } });

  const renderItem: ListRenderItem<Movie> = ({ item }) => <MoviePosterCard movie={item} onPress={() => openMovie(item)} favorite={isFavorite(item.identifier)} onToggleFavorite={() => void toggleFavorite(item)} />;
  const header = <View style={{ paddingTop: 7 }}>
    <TopBar title="INS4N3" subtitle="THE PUBLIC-DOMAIN CINEMA" right={<Pressable style={{ width: 43, height: 43, borderRadius: 15, backgroundColor: C.card, borderWidth: 1, borderColor: C.line, alignItems: "center", justifyContent: "center" }} onPress={() => router.push("/search")}><Ionicons name="search" size={19} color={C.cyan} /></Pressable>} />
    <View style={{ paddingHorizontal: 20, paddingTop: 15 }}>
      <Text style={{ color: C.text, fontSize: 26, fontWeight: "800", lineHeight: 32, letterSpacing: -0.3 }}>Great films.{"\n"}<Text style={{ color: C.cyan }}>Free forever.</Text></Text>
      <Text style={{ color: C.muted, marginTop: 7, fontSize: 13, lineHeight: 19 }}>Discover movies identified as public domain and hosted by the Internet Archive.</Text>
      <View style={{ marginTop: 18 }}><SearchField value={query} onChangeText={setQuery} onSubmitEditing={submitSearch} /></View>
      <SectionTitle title="Browse by mood" />
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginRight: -20 }} contentContainerStyle={{ paddingRight: 20 }}>
        {categories.map((item) => <CategoryChip key={item} label={item} selected={category === item} onPress={() => setCategory(item)} />)}
      </ScrollView>
      <SectionTitle title={category === "All" ? "From the archive" : category} action={movies.length ? `${movies.length} films` : undefined} />
    </View>
  </View>;

  return <FlatList data={movies} keyExtractor={(item) => item.identifier} renderItem={renderItem} numColumns={2} columnWrapperStyle={{ gap: 13, paddingHorizontal: 20 }} contentContainerStyle={{ paddingBottom: 3 }} ListHeaderComponent={header} ListFooterComponent={<View style={{ paddingHorizontal: 20 }}>{error ? <ErrorBanner message={error} onRetry={() => void loadPage(movies.length ? page + 1 : 1, movies.length === 0)} /> : null}{loading ? <ActivityIndicator color={C.cyan} style={{ marginVertical: 22 }} /> : null}{!loading && !error && movies.length === 0 ? <EmptyState title="No films found" body="No public-domain items were returned for this category. Try another genre." /> : null}{hasMore && !loading && movies.length > 0 ? <Pressable onPress={() => void loadPage(page + 1)} style={{ padding: 17, alignItems: "center" }}><Text style={{ color: C.cyan, fontSize: 12, fontWeight: "800" }}>LOAD MORE FILMS</Text></Pressable> : null}<PoweredFooter /></View>} ListEmptyComponent={loading ? null : null} onEndReachedThreshold={0.35} onEndReached={() => { if (hasMore && !loading && !error) void loadPage(page + 1); }} refreshing={refreshing} onRefresh={() => { setRefreshing(true); void loadPage(1, true); }} showsVerticalScrollIndicator={false} />;
}
