import { Ionicons } from "@expo/vector-icons";
import { Image } from "expo-image";
import { useRouter } from "expo-router";
import { useMemo, useState } from "react";
import { Alert, FlatList, Pressable, StyleSheet, Text, View } from "react-native";
import { C, EmptyState, TopBar } from "@/components/moviebox-ui";
import { formatBytes, posterUrl } from "@/lib/archive";
import { useMovieBox } from "@/lib/moviebox/context";
import type { DownloadRecord } from "@/lib/moviebox/types";

function DownloadCard({ record }: { record: DownloadRecord }) {
  const router = useRouter();
  const { pauseDownload, resumeDownload, cancelDownload, retryDownload, deleteDownload } = useMovieBox();
  const [working, setWorking] = useState(false);
  const progress = record.bytesTotal > 0 ? Math.max(0, Math.min(1, record.bytesDownloaded / record.bytesTotal)) : 0;
  const run = async (operation: () => Promise<void>) => {
    if (working) return;
    setWorking(true);
    try { await operation(); } catch (err) { Alert.alert("Download action failed", err instanceof Error ? err.message : "Try again."); }
    finally { setWorking(false); }
  };
  const confirmDelete = () => Alert.alert("Delete download?", `Remove ${record.movie.title} from this device?`, [{ text: "Keep", style: "cancel" }, { text: "Delete", style: "destructive", onPress: () => void run(() => deleteDownload(record.taskId)) }]);
  const isBusy = record.status === "queued" || record.status === "downloading" || record.status === "copying";
  const canControlTransfer = record.status === "queued" || record.status === "downloading";
  return <View style={styles.card}>
    <Pressable onPress={() => { if (record.status === "completed" && record.localUri) router.push({ pathname: "/player", params: { uri: record.localUri, title: record.movie.title, offline: "1", movie: JSON.stringify(record.movie) } }); }} style={styles.body}>
      <Image source={{ uri: posterUrl(record.movie.identifier) }} contentFit="cover" style={styles.poster} />
      <View style={{ flex: 1 }}><Text numberOfLines={2} style={styles.title}>{record.movie.title}</Text><Text style={styles.subtitle}>{record.movie.year || "Archive film"} · {record.file.label} · {formatBytes(record.file.bytes)}</Text><Text style={[styles.status, record.status === "completed" ? { color: C.green } : record.status === "failed" ? { color: C.red } : { color: C.cyan }]}>{record.status === "copying" ? "SAVING TO FOLDER" : record.status === "downloading" || record.status === "queued" ? `${Math.round(progress * 100)}%  ·  ${formatBytes(record.bytesPerSecond)}/s` : record.status.toUpperCase()}</Text>{isBusy ? <View style={styles.progressTrack}><View style={[styles.progressFill, { width: `${Math.round(progress * 100)}%` }]} /></View> : null}{record.error ? <Text numberOfLines={2} style={styles.error}>{record.error}</Text> : null}</View>
      {record.status === "completed" ? <Ionicons name="play-circle" color={C.cyan} size={27} /> : null}
    </Pressable>
    <View style={styles.controls}>
      {record.status === "downloading" || record.status === "queued" ? <Pressable onPress={() => void run(() => pauseDownload(record.taskId))} style={styles.control}><Ionicons name="pause" size={16} color={C.text} /><Text style={styles.controlText}>Pause</Text></Pressable> : null}
      {record.status === "paused" ? <Pressable onPress={() => void run(() => resumeDownload(record.taskId))} style={styles.control}><Ionicons name="play" size={16} color={C.cyan} /><Text style={[styles.controlText, { color: C.cyan }]}>Resume</Text></Pressable> : null}
      {record.status === "failed" || record.status === "cancelled" ? <Pressable onPress={() => void run(() => retryDownload(record.taskId))} style={styles.control}><Ionicons name="refresh" size={16} color={C.cyan} /><Text style={[styles.controlText, { color: C.cyan }]}>Retry</Text></Pressable> : null}
      {canControlTransfer ? <Pressable onPress={() => void run(() => cancelDownload(record.taskId))} style={styles.control}><Ionicons name="close-circle-outline" size={16} color={C.muted} /><Text style={styles.controlText}>Cancel</Text></Pressable> : null}
      <Pressable onPress={confirmDelete} style={styles.control}><Ionicons name="trash-outline" size={15} color={C.red} /><Text style={[styles.controlText, { color: C.red }]}>Delete</Text></Pressable>
    </View>
  </View>;
}

const styles = StyleSheet.create({ card: { backgroundColor: C.card, borderWidth: 1, borderColor: C.line, borderRadius: 16, padding: 12, marginHorizontal: 20, marginBottom: 11 }, body: { flexDirection: "row", alignItems: "center", gap: 12 }, poster: { width: 56, height: 76, borderRadius: 10, backgroundColor: C.raised }, title: { color: C.text, fontSize: 14, fontWeight: "700" }, subtitle: { color: C.muted, fontSize: 10, marginTop: 5 }, status: { color: C.cyan, fontSize: 9, fontWeight: "800", marginTop: 7, letterSpacing: 0.6 }, progressTrack: { height: 4, backgroundColor: "#272739", borderRadius: 3, marginTop: 7, overflow: "hidden" }, progressFill: { height: 4, backgroundColor: C.cyan, borderRadius: 3 }, error: { color: C.red, fontSize: 10, marginTop: 5 }, controls: { flexDirection: "row", flexWrap: "wrap", gap: 9, paddingTop: 12, marginTop: 10, borderTopWidth: 1, borderTopColor: "#232333" }, control: { flexDirection: "row", alignItems: "center", gap: 5, backgroundColor: C.raised, borderRadius: 8, paddingHorizontal: 9, paddingVertical: 6 }, controlText: { color: C.text, fontSize: 10, fontWeight: "700" } } as const);

export default function DownloadsScreen() {
  const { downloads } = useMovieBox();
  const [view, setView] = useState<"library" | "manager">("library");
  const shown = useMemo(() => view === "library" ? downloads.filter((item) => item.status === "completed") : downloads.filter((item) => item.status !== "completed"), [downloads, view]);
  return <View style={{ flex: 1, backgroundColor: C.bg }}>
    <FlatList data={shown} keyExtractor={(item) => item.taskId} renderItem={({ item }) => <DownloadCard record={item} />} contentContainerStyle={{ paddingBottom: 30 }} ListHeaderComponent={<View style={{ paddingTop: 8 }}><TopBar title="My Downloads" subtitle="OFFLINE AND IN PROGRESS" /><View style={tabStyles.switcher}><Pressable onPress={() => setView("library")} style={[tabStyles.switch, view === "library" && tabStyles.active]}><Text style={[tabStyles.switchText, view === "library" && { color: C.cyan }]}>OFFLINE ({downloads.filter((item) => item.status === "completed").length})</Text></Pressable><Pressable onPress={() => setView("manager")} style={[tabStyles.switch, view === "manager" && tabStyles.active]}><Text style={[tabStyles.switchText, view === "manager" && { color: C.cyan }]}>TRANSFERS ({downloads.filter((item) => item.status !== "completed").length})</Text></Pressable></View></View>} ListEmptyComponent={<EmptyState icon={view === "library" ? "cloud-download-outline" : "checkmark-done-outline"} title={view === "library" ? "Nothing downloaded yet" : "All caught up"} body={view === "library" ? "Downloaded films stay on this device for offline playback." : "New and active downloads will appear here."} />} showsVerticalScrollIndicator={false} />
  </View>;
}

const tabStyles = StyleSheet.create({ switcher: { flexDirection: "row", marginHorizontal: 20, backgroundColor: C.card, padding: 4, borderRadius: 12, marginTop: 10, marginBottom: 16, borderWidth: 1, borderColor: C.line }, switch: { flex: 1, paddingVertical: 10, alignItems: "center", borderRadius: 9 }, active: { backgroundColor: "#10202A", borderWidth: 1, borderColor: "#17505B" }, switchText: { color: C.muted, fontSize: 10, fontWeight: "800", letterSpacing: 0.5 } } as const);
