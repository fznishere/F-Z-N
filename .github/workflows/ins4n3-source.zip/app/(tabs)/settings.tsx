import { Ionicons } from "@expo/vector-icons";
import * as FileSystem from "expo-file-system/legacy";
import { useState } from "react";
import { ActivityIndicator, Alert, Pressable, ScrollView, StyleSheet, Switch, Text, View } from "react-native";
import { C, TopBar } from "@/components/moviebox-ui";
import { useMovieBox } from "@/lib/moviebox/context";

function Row({ icon, title, detail, trailing, onPress }: { icon: keyof typeof Ionicons.glyphMap; title: string; detail?: string; trailing?: React.ReactNode; onPress?: () => void }) {
  return <Pressable onPress={onPress} disabled={!onPress} style={styles.row}><View style={styles.rowIcon}><Ionicons name={icon} size={18} color={C.cyan} /></View><View style={{ flex: 1 }}><Text style={styles.rowTitle}>{title}</Text>{detail ? <Text style={styles.rowDetail}>{detail}</Text> : null}</View>{trailing}</Pressable>;
}

export default function SettingsScreen() {
  const { settings, setWifiOnly, setDownloadDirectoryLabel, clearCache } = useMovieBox();
  const [busy, setBusy] = useState(false);
  const chooseFolder = async () => {
    try {
      if (!FileSystem.StorageAccessFramework?.requestDirectoryPermissionsAsync) {
        Alert.alert("App storage", "This platform does not support choosing a shared download folder. INS4N3 keeps downloaded films in its private app storage.");
        return;
      }
      const result = await FileSystem.StorageAccessFramework.requestDirectoryPermissionsAsync();
      if (result.granted) {
        await setDownloadDirectoryLabel("Custom folder selected", result.directoryUri);
        Alert.alert("Folder selected", "Completed downloads will be copied to this folder. INS4N3 also keeps a private copy for offline playback.");
      }
    } catch {
      Alert.alert("Folder unavailable", "INS4N3 could not access the selected folder. App storage remains available.");
    }
  };
  const confirmClear = () => Alert.alert("Clear cache?", "This clears temporary catalogue cache only. Your films and favourites will stay on this device.", [{ text: "Cancel", style: "cancel" }, { text: "Clear", style: "destructive", onPress: () => { setBusy(true); void clearCache().then(() => Alert.alert("Cache cleared", "Temporary cache has been removed.")).finally(() => setBusy(false)); } }]);
  return <ScrollView style={{ flex: 1, backgroundColor: C.bg }} contentContainerStyle={{ paddingBottom: 40 }} showsVerticalScrollIndicator={false}>
    <View style={{ paddingTop: 8 }}><TopBar title="Settings" subtitle="PREFERENCES AND ABOUT" /></View>
    <Text style={styles.groupTitle}>DOWNLOADS</Text>
    <View style={styles.group}>
      <Row icon="folder-open-outline" title="Download location" detail={settings.downloadDirectoryLabel} trailing={<Ionicons name="chevron-forward" size={17} color={C.dim} />} onPress={() => void chooseFolder()} />
      <View style={styles.separator} />
      <Row icon="wifi-outline" title="Wi-Fi only" detail="Pause new downloads on mobile data" trailing={<Switch value={settings.wifiOnly} onValueChange={(value) => void setWifiOnly(value)} trackColor={{ false: "#323241", true: "#00747E" }} thumbColor={settings.wifiOnly ? C.cyan : "#A3A3B2"} />} />
      <View style={styles.separator} />
      <Row icon="trash-bin-outline" title="Clear cache" detail="Keeps offline films and favourites" trailing={busy ? <ActivityIndicator color={C.cyan} size="small" /> : <Ionicons name="chevron-forward" size={17} color={C.dim} />} onPress={busy ? undefined : confirmClear} />
    </View>
    <Text style={styles.groupTitle}>ABOUT</Text>
    <View style={styles.group}>
      <Row icon="film-outline" title="INS4N3" detail="Free cinema from the Internet Archive" trailing={<Text style={styles.version}>v1.0.0</Text>} />
      <View style={styles.separator} />
      <Row icon="globe-outline" title="Movie source" detail="Internet Archive · Public Domain only" />
      <View style={styles.separator} />
      <Row icon="heart-outline" title="Built with care by" detail="Powered by INS4N3" trailing={<Text style={styles.insane}>INS4N3</Text>} />
    </View>
    <View style={styles.notice}><Ionicons name="information-circle-outline" size={17} color={C.cyan} /><Text style={styles.noticeText}>INS4N3 indexes works that declare a Creative Commons Public Domain Mark or CC0 dedication. Publicity, privacy, trademark, and local legal restrictions may still apply.</Text></View>
    <Text style={styles.footer}>NO ADS  ·  NO ACCOUNT  ·  NO PAID APIs</Text>
  </ScrollView>;
}

const styles = StyleSheet.create({ groupTitle: { color: C.dim, fontSize: 9, fontWeight: "900", letterSpacing: 1.7, marginHorizontal: 23, marginTop: 25, marginBottom: 9 }, group: { marginHorizontal: 18, backgroundColor: C.card, borderWidth: 1, borderColor: C.line, borderRadius: 17, paddingHorizontal: 13 }, row: { minHeight: 69, flexDirection: "row", alignItems: "center", gap: 11, paddingVertical: 10 }, rowIcon: { width: 36, height: 36, borderRadius: 11, alignItems: "center", justifyContent: "center", backgroundColor: "#111923", borderWidth: 1, borderColor: "#1B3743" }, rowTitle: { color: C.text, fontSize: 13, fontWeight: "700" }, rowDetail: { color: C.muted, fontSize: 10, lineHeight: 15, marginTop: 3 }, separator: { height: 1, backgroundColor: "#242433", marginLeft: 47 }, version: { color: C.dim, fontSize: 10, fontWeight: "700" }, insane: { color: C.magenta, fontSize: 11, fontWeight: "900", letterSpacing: 1.1 }, notice: { flexDirection: "row", gap: 9, marginHorizontal: 20, marginTop: 19, padding: 12, borderRadius: 13, backgroundColor: "#0B1720", borderWidth: 1, borderColor: "#17343E" }, noticeText: { flex: 1, color: C.muted, fontSize: 10, lineHeight: 16 }, footer: { color: C.dim, textAlign: "center", marginTop: 25, fontSize: 8, letterSpacing: 1.2, fontWeight: "800" } } as const);
