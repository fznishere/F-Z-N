import { Ionicons } from "@expo/vector-icons";
import * as Brightness from "expo-brightness";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useEvent } from "expo";
import { useVideoPlayer, VideoView } from "expo-video";
import { useEffect, useMemo, useRef, useState } from "react";
import { ActivityIndicator, Alert, Dimensions, PanResponder, Pressable, StyleSheet, Text, View } from "react-native";
import { C } from "@/components/moviebox-ui";

const WINDOW_HEIGHT = Dimensions.get("window").height;

export default function PlayerScreen() {
  const params = useLocalSearchParams<{ uri?: string; title?: string; offline?: string }>();
  const router = useRouter();
  const uri = params.uri ?? "";
  const source = useMemo(() => ({ uri }), [uri]);
  const player = useVideoPlayer(source, (instance) => { instance.timeUpdateEventInterval = 1; instance.play(); });
  const status = useEvent(player, "statusChange", { status: player.status });
  const [brightness, setBrightness] = useState(0.55);
  const [gestureHint, setGestureHint] = useState("");
  const [gestureSideForUi, setGestureSideForUi] = useState<"left" | "right">("left");
  const gestureSide = useRef<"left" | "right">("left");
  const gestureStart = useRef(0);
  const hideHintTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => { void Brightness.getBrightnessAsync().then(setBrightness).catch(() => undefined); return () => { if (hideHintTimer.current) clearTimeout(hideHintTimer.current); }; }, []);
  useEffect(() => { if (status.status === "error") Alert.alert("Playback error", "This video format may not be supported by this Android device. Try another quality or check your connection."); }, [status.status]);

  // PanResponder callbacks run later from native touch events; refs are intentionally captured here.
  // eslint-disable-next-line react-hooks/refs
  const panResponder = useMemo(() => PanResponder.create({
    onStartShouldSetPanResponder: () => false,
    onMoveShouldSetPanResponder: (_event, gesture) => Math.abs(gesture.dy) > 7 && Math.abs(gesture.dy) > Math.abs(gesture.dx) * 1.1,
    onPanResponderGrant: (event) => {
      gestureSide.current = event.nativeEvent.pageX < Dimensions.get("window").width * 0.5 ? "left" : "right";
      setGestureSideForUi(gestureSide.current);
      gestureStart.current = gestureSide.current === "left" ? brightness : player.volume;
    },
    onPanResponderMove: (_event, gesture) => {
      const delta = Math.max(-1, Math.min(1, -gesture.dy / (WINDOW_HEIGHT * 0.75)));
      const value = Math.max(0, Math.min(1, gestureStart.current + delta));
      if (gestureSide.current === "left") {
        setBrightness(value);
        void Brightness.setBrightnessAsync(value).catch(() => undefined);
        setGestureHint(`BRIGHTNESS  ${Math.round(value * 100)}%`);
      } else {
        // Expo Video documents volume as an imperative native player property.
        // eslint-disable-next-line react-hooks/immutability
        player.volume = value;
        setGestureHint(`VOLUME  ${Math.round(value * 100)}%`);
      }
      if (hideHintTimer.current) clearTimeout(hideHintTimer.current);
      hideHintTimer.current = setTimeout(() => setGestureHint(""), 850);
    },
  }), [brightness, player]);

  if (!uri) return <View style={styles.error}><Text style={styles.errorTitle}>No video selected</Text><Pressable onPress={() => router.back()}><Text style={{ color: C.cyan }}>Go back</Text></Pressable></View>;
  return <View style={styles.root} {...panResponder.panHandlers}>
    <VideoView player={player} style={StyleSheet.absoluteFill} nativeControls fullscreenOptions={{ enable: true }} contentFit="contain" allowsPictureInPicture />
    <View style={styles.topOverlay} pointerEvents="box-none"><Pressable onPress={() => router.back()} style={styles.back}><Ionicons name="chevron-back" size={23} color={C.text} /></Pressable><View style={{ flex: 1 }}><Text numberOfLines={1} style={styles.movieTitle}>{params.title || "INS4N3 player"}</Text><Text style={styles.source}>{params.offline === "1" ? "OFFLINE PLAYBACK" : "INTERNET ARCHIVE STREAM"}</Text></View><View style={styles.liveDot} /></View>
    <View style={styles.gestureLeft} pointerEvents="none" /><View style={styles.gestureRight} pointerEvents="none" />
    {status.status === "loading" || status.status === "idle" ? <View pointerEvents="none" style={styles.loading}><ActivityIndicator color={C.cyan} size="large" /><Text style={styles.loadingText}>Loading film…</Text></View> : null}
    {gestureHint ? <View pointerEvents="none" style={styles.gestureToast}><Ionicons name={gestureSideForUi === "left" ? "sunny" : "volume-high"} size={17} color={C.cyan} /><Text style={styles.gestureText}>{gestureHint}</Text></View> : null}
    <View pointerEvents="none" style={styles.bottomHint}><Ionicons name="swap-vertical" size={13} color={C.muted} /><Text style={styles.bottomHintText}>Swipe left side for brightness · right side for volume</Text></View>
  </View>;
}

const styles = StyleSheet.create({ root: { flex: 1, backgroundColor: "#000", justifyContent: "center" }, topOverlay: { position: "absolute", top: 53, left: 15, right: 15, flexDirection: "row", alignItems: "center", gap: 10, backgroundColor: "rgba(5,5,10,0.7)", borderRadius: 15, padding: 10 }, back: { width: 38, height: 38, borderRadius: 12, backgroundColor: "rgba(20,20,33,0.9)", alignItems: "center", justifyContent: "center" }, movieTitle: { color: C.text, fontSize: 13, fontWeight: "800" }, source: { color: C.cyan, fontSize: 8, fontWeight: "800", letterSpacing: 1, marginTop: 4 }, liveDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: C.magenta, shadowColor: C.magenta, shadowOpacity: 0.8, shadowRadius: 7 }, gestureLeft: { position: "absolute", top: 100, bottom: 65, left: 0, width: "49%" }, gestureRight: { position: "absolute", top: 100, bottom: 65, right: 0, width: "49%" }, loading: { position: "absolute", alignSelf: "center", alignItems: "center", gap: 10 }, loadingText: { color: C.muted, fontSize: 11 }, gestureToast: { position: "absolute", alignSelf: "center", top: "44%", flexDirection: "row", gap: 9, alignItems: "center", backgroundColor: "rgba(8,10,18,0.86)", borderRadius: 14, borderWidth: 1, borderColor: "#26414A", paddingHorizontal: 14, paddingVertical: 10 }, gestureText: { color: C.text, fontSize: 12, fontWeight: "800" }, bottomHint: { position: "absolute", bottom: 21, alignSelf: "center", flexDirection: "row", alignItems: "center", gap: 5, paddingHorizontal: 10, paddingVertical: 6, borderRadius: 11, backgroundColor: "rgba(5,5,10,0.7)" }, bottomHintText: { color: C.muted, fontSize: 9 }, error: { flex: 1, backgroundColor: C.bg, alignItems: "center", justifyContent: "center", gap: 13 }, errorTitle: { color: C.text, fontSize: 18, fontWeight: "800" } } as const);
