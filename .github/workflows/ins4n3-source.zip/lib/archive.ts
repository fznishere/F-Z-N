import type { ArchiveFile, ArchiveMetadata, Movie, MovieCategory, MovieQuality } from "@/lib/moviebox/types";

const SEARCH_ENDPOINT = "https://archive.org/advancedsearch.php";
const METADATA_ENDPOINT = "https://archive.org/metadata";
const IMAGE_ENDPOINT = "https://archive.org/services/img";
const ITEM_ENDPOINT = "https://archive.org/download";
const PUBLIC_DOMAIN_LICENSES = new Set([
  "https://creativecommons.org/publicdomain/mark/1.0/",
  "http://creativecommons.org/publicdomain/mark/1.0/",
  "https://creativecommons.org/publicdomain/zero/1.0/",
  "http://creativecommons.org/publicdomain/zero/1.0/",
]);

export function isPublicDomainLicense(license?: string): boolean {
  return PUBLIC_DOMAIN_LICENSES.has((license ?? "").trim().toLowerCase());
}

function escapeLucene(value: string): string {
  return value.replace(/[+\-!(){}\[\]^"~*?:\\/]/g, "\\$&").trim();
}

const licenseQuery = `licenseurl:("https://creativecommons.org/publicdomain/mark/1.0/" OR "http://creativecommons.org/publicdomain/mark/1.0/" OR "https://creativecommons.org/publicdomain/zero/1.0/" OR "http://creativecommons.org/publicdomain/zero/1.0/")`;

const CATEGORY_QUERIES: Partial<Record<MovieCategory, string>> = {
  Classic: "year:[1900 TO 1965]",
  "Sci-Fi": '(subject:"science fiction" OR subject:"sci-fi" OR subject:"science-fiction")',
  Horror: '(subject:horror OR subject:"horror films")',
  Comedy: '(subject:comedy OR subject:"comedies")',
  Drama: '(subject:drama OR subject:"dramatic films")',
  Animation: '(subject:animation OR subject:animated OR subject:cartoon)',
  Documentary: '(subject:documentary OR subject:documentaries)',
};

export function buildSearchQuery(options: { title?: string; category?: MovieCategory }): string {
  const parts = ["collection:feature_films", "mediatype:movies", licenseQuery];
  if (options.title?.trim()) parts.push(`title:(${escapeLucene(options.title)})`);
  const categoryQuery = options.category ? CATEGORY_QUERIES[options.category] : undefined;
  if (categoryQuery) parts.push(categoryQuery);
  return parts.join(" AND ");
}

function first(value: unknown): string | undefined {
  if (Array.isArray(value)) return value.length ? String(value[0]) : undefined;
  return value == null || value === "" ? undefined : String(value);
}

function asMovie(raw: Record<string, unknown>): Movie | null {
  const identifier = first(raw.identifier);
  const licenseurl = first(raw.licenseurl);
  if (!identifier || !isPublicDomainLicense(licenseurl)) return null;
  const subject = raw.subject;
  return {
    identifier,
    title: first(raw.title) ?? identifier.replace(/[_-]+/g, " "),
    year: first(raw.year),
    description: first(raw.description),
    licenseurl,
    subject: Array.isArray(subject) ? subject.map(String) : first(subject),
    runtime: first(raw.runtime),
    size: first(raw.size),
  };
}

export function posterUrl(identifier: string): string {
  return `${IMAGE_ENDPOINT}/${encodeURIComponent(identifier)}`;
}

export function itemUrl(identifier: string): string {
  return `https://archive.org/details/${encodeURIComponent(identifier)}`;
}

export function fileDownloadUrl(identifier: string, filename: string): string {
  return `${ITEM_ENDPOINT}/${encodeURIComponent(identifier)}/${filename.split("/").map(encodeURIComponent).join("/")}`;
}

export async function searchMovies(options: {
  page?: number;
  rows?: number;
  title?: string;
  category?: MovieCategory;
  signal?: AbortSignal;
}): Promise<{ movies: Movie[]; total: number; page: number }> {
  const page = Math.max(1, options.page ?? 1);
  const rows = Math.min(50, Math.max(1, options.rows ?? 30));
  const params = new URLSearchParams();
  params.set("q", buildSearchQuery(options));
  ["identifier", "title", "year", "description", "licenseurl", "subject", "runtime", "size"].forEach((field) => params.append("fl[]", field));
  params.set("rows", String(rows));
  params.set("page", String(page));
  params.set("output", "json");

  const response = await fetch(`${SEARCH_ENDPOINT}?${params.toString()}`, { signal: options.signal });
  if (!response.ok) throw new Error(response.status === 404 ? "The Archive.org search endpoint was not found." : `Archive.org search failed (${response.status}).`);
  const payload = (await response.json()) as { response?: { docs?: Record<string, unknown>[]; numFound?: number } };
  const docs = payload.response?.docs ?? [];
  const movies = docs.map(asMovie).filter((movie): movie is Movie => Boolean(movie));
  return { movies, total: Number(payload.response?.numFound ?? movies.length), page };
}

export async function getMovie(identifier: string, signal?: AbortSignal): Promise<Movie> {
  const params = new URLSearchParams({ q: `identifier:${escapeLucene(identifier)} AND collection:feature_films AND mediatype:movies AND ${licenseQuery}`, output: "json" });
  ["identifier", "title", "year", "description", "licenseurl", "subject", "runtime", "size"].forEach((field) => params.append("fl[]", field));
  params.set("rows", "2");
  const response = await fetch(`${SEARCH_ENDPOINT}?${params.toString()}`, { signal });
  if (!response.ok) throw new Error(`Movie lookup failed (${response.status}).`);
  const payload = (await response.json()) as { response?: { docs?: Record<string, unknown>[] } };
  const exact = (payload.response?.docs ?? []).map(asMovie).find((movie) => movie?.identifier === identifier);
  if (!exact) throw new Error("This item is not listed with an explicit public-domain license, so INS4N3 will not play or download it.");
  return exact;
}

export async function getMovieMetadata(identifier: string, signal?: AbortSignal): Promise<ArchiveMetadata> {
  const response = await fetch(`${METADATA_ENDPOINT}/${encodeURIComponent(identifier)}`, { signal });
  if (!response.ok) throw new Error(response.status === 404 ? "Movie metadata was not found." : `Could not load movie files (${response.status}).`);
  const data = (await response.json()) as ArchiveMetadata;
  if (data.error || !data.metadata || !Array.isArray(data.files)) throw new Error(data.error || "This Archive.org item is missing its media files.");
  if (!isPublicDomainLicense(first(data.metadata.licenseurl))) throw new Error("The item does not declare an accepted public-domain license.");
  return data;
}

function isVideoFile(file: ArchiveFile): boolean {
  const name = file.name.toLowerCase();
  const format = (file.format ?? "").toLowerCase();
  const extensionAllowed = /\.(mp4|ogv|mkv|avi|h264)$/i.test(name) || /512kb\.mp4$/i.test(name);
  const recognizedH264 = format.includes("h.264") || format.includes("h264") || format.includes("512kb mp4");
  return (extensionAllowed || recognizedH264) && !/\.torrent$|\.xml$|\.srt$|\.jpg$|\.jpeg$|\.png$/i.test(name);
}

function qualityLabel(file: ArchiveFile, bytes: number): string {
  const text = `${file.name} ${file.format ?? ""}`.toLowerCase();
  const height = Number(file.height ?? 0);
  if (height >= 1080 || /1080p|full\s?hd/.test(text)) return "Full HD";
  if (height >= 720 || /720p|hd/.test(text)) return "HD";
  if (/512kb|low|240p|360p|lo\s?res/.test(text)) return "Low";
  if (height >= 480 || /480p|standard|mpeg4/.test(text)) return "Standard";
  if (bytes >= 1_500_000_000) return "HD";
  return "Standard";
}

export function listMovieQualities(identifier: string, files: ArchiveFile[]): MovieQuality[] {
  return files
    .filter(isVideoFile)
    .map((file) => {
      const bytes = Number(file.size ?? 0);
      return { ...file, bytes, label: qualityLabel(file, bytes), downloadUrl: fileDownloadUrl(identifier, file.name) };
    })
    .sort((a, b) => b.bytes - a.bytes || a.name.localeCompare(b.name));
}

export function formatBytes(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes <= 0) return "Size unavailable";
  if (bytes >= 1024 ** 3) return `${(bytes / 1024 ** 3).toFixed(1)} GB`;
  return `${(bytes / 1024 ** 2).toFixed(1)} MB`;
}

export function metadataRuntime(metadata: ArchiveMetadata): string | undefined {
  const value = first(metadata.metadata?.runtime);
  return value?.replace(/\s+/g, " ").trim();
}

export function metadataSize(metadata: ArchiveMetadata): string | undefined {
  const fromMetadata = first(metadata.metadata?.size);
  const bytes = Number(metadata.item_size ?? fromMetadata);
  return Number.isFinite(bytes) && bytes > 0 ? formatBytes(bytes) : fromMetadata;
}
