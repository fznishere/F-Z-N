import { afterEach, describe, expect, it, vi } from "vitest";
import { buildSearchQuery, fileDownloadUrl, formatBytes, getMovie, isPublicDomainLicense, listMovieQualities, searchMovies } from "./archive";
import type { ArchiveFile } from "./moviebox/types";

afterEach(() => vi.unstubAllGlobals());

describe("public-domain licensing", () => {
  it("accepts only explicit PDM 1.0 and CC0 1.0 URLs", () => {
    expect(isPublicDomainLicense("https://creativecommons.org/publicdomain/mark/1.0/")).toBe(true);
    expect(isPublicDomainLicense("http://creativecommons.org/publicdomain/zero/1.0/")).toBe(true);
    expect(isPublicDomainLicense("https://creativecommons.org/licenses/by/4.0/")).toBe(false);
    expect(isPublicDomainLicense(undefined)).toBe(false);
  });
});

describe("Archive.org search", () => {
  it("keeps collection, movie, title, and explicit license restrictions in the query", () => {
    const query = buildSearchQuery({ title: "The Night (1930)", category: "Horror" });
    expect(query).toContain("collection:feature_films");
    expect(query).toContain("mediatype:movies");
    expect(query).toContain("title:(The Night \\\(1930\\\))");
    expect(query).toContain("licenseurl:");
    expect(query).toContain("subject:horror");
  });

  it("does not perform a broad unrelated search before exact identifier lookup", async () => {
    const json = { response: { docs: [{ identifier: "public-item", title: "Public Item", licenseurl: "https://creativecommons.org/publicdomain/mark/1.0/" }] } };
    const fetchMock = vi.fn().mockResolvedValue({ ok: true, json: async () => json });
    vi.stubGlobal("fetch", fetchMock);
    const movie = await getMovie("public-item");
    expect(movie.identifier).toBe("public-item");
    expect(fetchMock).toHaveBeenCalledTimes(1);
    expect(decodeURIComponent(String(fetchMock.mock.calls[0][0]))).toContain("identifier:public\\-item");
  });

  it("requests title-filtered pages and drops records without an accepted license", async () => {
    const json = { response: { numFound: 2, docs: [
      { identifier: "legal", title: "Night Film", licenseurl: "https://creativecommons.org/publicdomain/zero/1.0/" },
      { identifier: "unverified", title: "Night Film", licenseurl: "https://creativecommons.org/licenses/by/4.0/" },
    ] } };
    const fetchMock = vi.fn().mockResolvedValue({ ok: true, json: async () => json });
    vi.stubGlobal("fetch", fetchMock);
    const result = await searchMovies({ title: "Night Film", page: 2, rows: 30 });
    const url = new URL(String(fetchMock.mock.calls[0][0]));
    expect(url.searchParams.get("page")).toBe("2");
    expect(url.searchParams.get("rows")).toBe("30");
    expect(url.searchParams.get("q")).toContain("title:(Night Film)");
    expect(result.movies.map((movie) => movie.identifier)).toEqual(["legal"]);
  });
});

describe("quality filtering and ordering", () => {
  const files: ArchiveFile[] = [
    { name: "feature-film-720p.mp4", format: "MPEG4", size: "720000000" },
    { name: "feature-film-512kb.mp4", format: "512Kb MPEG4", size: "65000000" },
    { name: "feature-film-1080p.mkv", format: "Matroska", size: "1500000000" },
    { name: "captions.srt", format: "SubRip", size: "40000" },
    { name: "archive.torrent", format: "BitTorrent", size: "200000" },
    { name: "legacy-video", format: "H.264", size: "90000000" },
    { name: "feature-film.h264", format: "Raw H.264", size: "50000000" },
  ];

  it("keeps eligible videos only and sorts high-to-low by metadata size", () => {
    const result = listMovieQualities("legal-item", files);
    expect(result.map((file) => file.name)).toEqual([
      "feature-film-1080p.mkv",
      "feature-film-720p.mp4",
      "legacy-video",
      "feature-film-512kb.mp4",
      "feature-film.h264",
    ]);
    expect(result.map((file) => file.label)).toEqual(["Full HD", "HD", "Standard", "Low", "Standard"]);
    expect(result[0].downloadUrl).toBe(fileDownloadUrl("legal-item", "feature-film-1080p.mkv"));
  });

  it("formats MB and GB sizes from bytes", () => {
    expect(formatBytes(1048576)).toBe("1.0 MB");
    expect(formatBytes(2147483648)).toBe("2.0 GB");
    expect(formatBytes(0)).toBe("Size unavailable");
  });
});
