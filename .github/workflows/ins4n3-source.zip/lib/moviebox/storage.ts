import AsyncStorage from "@react-native-async-storage/async-storage";
import type { AppSettings, DownloadRecord, Movie } from "@/lib/moviebox/types";

const KEYS = {
  favorites: "moviebox.v1.favorites",
  downloads: "moviebox.v1.downloads",
  settings: "moviebox.v1.settings",
} as const;

const DEFAULT_SETTINGS: AppSettings = { wifiOnly: false, downloadDirectoryLabel: "App storage" };

async function readJson<T>(key: string, fallback: T): Promise<T> {
  try {
    const raw = await AsyncStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

export const loadFavorites = () => readJson<Movie[]>(KEYS.favorites, []);
export const saveFavorites = (movies: Movie[]) => AsyncStorage.setItem(KEYS.favorites, JSON.stringify(movies));
export const loadDownloads = () => readJson<DownloadRecord[]>(KEYS.downloads, []);
export const saveDownloads = (records: DownloadRecord[]) => AsyncStorage.setItem(KEYS.downloads, JSON.stringify(records));
export const loadSettings = () => readJson<AppSettings>(KEYS.settings, DEFAULT_SETTINGS);
export const saveSettings = (settings: AppSettings) => AsyncStorage.setItem(KEYS.settings, JSON.stringify(settings));

export async function clearMovieCache(): Promise<void> {
  // Catalogue data is fetched on demand; remove only transient cached search state, never
  // the durable favourites, download index, or downloaded files.
  await AsyncStorage.removeItem("moviebox.v1.catalog-cache");
}
