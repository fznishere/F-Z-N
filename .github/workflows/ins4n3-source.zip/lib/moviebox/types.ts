export type Movie = {
  identifier: string;
  title: string;
  year?: string;
  description?: string;
  licenseurl?: string;
  subject?: string[] | string;
  runtime?: string;
  size?: string;
};

export type ArchiveFile = {
  name: string;
  format?: string;
  size?: string;
  source?: string;
  length?: string;
  width?: string;
  height?: string;
};

export type MovieQuality = ArchiveFile & {
  label: string;
  bytes: number;
  downloadUrl: string;
};

export type ArchiveMetadata = {
  metadata?: Record<string, unknown>;
  files?: ArchiveFile[];
  item_size?: number | string;
  error?: string;
};

export type DownloadStatus = "queued" | "downloading" | "copying" | "paused" | "completed" | "failed" | "cancelled";

export type DownloadRecord = {
  taskId: string;
  movie: Movie;
  file: MovieQuality;
  destination: string;
  localUri?: string;
  sharedCopyUri?: string;
  status: DownloadStatus;
  bytesDownloaded: number;
  bytesTotal: number;
  bytesPerSecond: number;
  error?: string;
  updatedAt: number;
};

export type MovieCategory = "All" | "Classic" | "Sci-Fi" | "Horror" | "Comedy" | "Drama" | "Animation" | "Documentary";

export type AppSettings = {
  wifiOnly: boolean;
  downloadDirectoryLabel: string;
  downloadDirectoryUri?: string;
};
