import AsyncStorage from "@react-native-async-storage/async-storage";
import NetInfo from "expo-network";
import * as Notifications from "expo-notifications";
import * as FileSystem from "expo-file-system/legacy";
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import { Platform } from "react-native";
import { completeHandler, createDownloadTask, directories, getExistingDownloadTasks, setConfig, type DownloadTask } from "@kesha-antonov/react-native-background-downloader";
import type { AppSettings, DownloadRecord, Movie, MovieQuality } from "@/lib/moviebox/types";
import { clearMovieCache, loadDownloads, loadFavorites, loadSettings, saveDownloads, saveFavorites, saveSettings } from "@/lib/moviebox/storage";

const TASK_META_KEY = "moviebox.v1.background-task-meta";
const activeTasks = new Map<string, DownloadTask>();

type ContextValue = {
  favorites: Movie[];
  downloads: DownloadRecord[];
  settings: AppSettings;
  ready: boolean;
  toggleFavorite: (movie: Movie) => Promise<void>;
  isFavorite: (identifier: string) => boolean;
  startDownload: (movie: Movie, file: MovieQuality) => Promise<void>;
  pauseDownload: (taskId: string) => Promise<void>;
  resumeDownload: (taskId: string) => Promise<void>;
  cancelDownload: (taskId: string) => Promise<void>;
  retryDownload: (taskId: string) => Promise<void>;
  deleteDownload: (taskId: string) => Promise<void>;
  setWifiOnly: (enabled: boolean) => Promise<void>;
  setDownloadDirectoryLabel: (label: string, uri?: string) => Promise<void>;
  clearCache: () => Promise<void>;
};
const MovieBoxContext = createContext<ContextValue | null>(null);

function sanitizeFilename(value: string): string {
  return value.replace(/[^\w.\-]+/g, "_").replace(/^_+|_+$/g, "").slice(-130) || "movie.mp4";
}

async function copyToSafDirectory(sourceUri: string, directoryUri: string, filename: string, size: number, format?: string): Promise<string> {
  const safeName = sanitizeFilename(filename);
  const normalized = (format ?? "").toLowerCase();
  const mimeType = normalized.includes("matroska") || safeName.toLowerCase().endsWith(".mkv") ? "video/x-matroska"
    : normalized.includes("ogg") || safeName.toLowerCase().endsWith(".ogv") ? "video/ogg"
      : safeName.toLowerCase().endsWith(".avi") ? "video/x-msvideo" : "video/mp4";
  const baseName = safeName.replace(/\.[^.]+$/, "") || "movie";
  const destinationUri = await FileSystem.StorageAccessFramework.createFileAsync(directoryUri, baseName, mimeType);
  try {
    const chunkBytes = 768 * 1024;
    for (let position = 0; position < size; position += chunkBytes) {
      const length = Math.min(chunkBytes, size - position);
      const chunk = await FileSystem.readAsStringAsync(sourceUri, { encoding: FileSystem.EncodingType.Base64, position, length });
      await FileSystem.writeAsStringAsync(destinationUri, chunk, { encoding: FileSystem.EncodingType.Base64, append: position > 0 });
    }
    return destinationUri;
  } catch (error) {
    try { await FileSystem.deleteAsync(destinationUri, { idempotent: true }); } catch { /* Best-effort cleanup of an incomplete shared copy. */ }
    throw error;
  }
}

export function MovieBoxProvider({ children }: { children: React.ReactNode }) {
  const [favorites, setFavorites] = useState<Movie[]>([]);
  const [downloads, setDownloads] = useState<DownloadRecord[]>([]);
  const [settings, setSettings] = useState<AppSettings>({ wifiOnly: false, downloadDirectoryLabel: "App storage" });
  const settingsRef = useRef(settings);
  const [ready, setReady] = useState(false);

  const persistDownloads = useCallback((next: DownloadRecord[]) => {
    setDownloads(next);
    void saveDownloads(next);
  }, []);
  const updateDownload = useCallback((taskId: string, patch: Partial<DownloadRecord>) => {
    setDownloads((current) => {
      const next = current.map((record) => record.taskId === taskId ? { ...record, ...patch, updatedAt: Date.now() } : record);
      void saveDownloads(next);
      return next;
    });
  }, []);

  const bindTask = useCallback((task: DownloadTask, record: DownloadRecord) => {
    activeTasks.set(record.taskId, task);
    task.begin(({ expectedBytes }) => updateDownload(record.taskId, { status: "downloading", bytesTotal: expectedBytes || record.bytesTotal, error: undefined }));
    let lastBytes = record.bytesDownloaded;
    let lastTime = Date.now();
    task.progress(({ bytesDownloaded, bytesTotal }) => {
      const now = Date.now();
      const elapsed = Math.max(0.25, (now - lastTime) / 1000);
      const speed = Math.max(0, (bytesDownloaded - lastBytes) / elapsed);
      lastBytes = bytesDownloaded;
      lastTime = now;
      updateDownload(record.taskId, { status: "downloading", bytesDownloaded, bytesTotal, bytesPerSecond: speed });
    });
    task.done(({ location, bytesDownloaded, bytesTotal }) => {
      const localUri = location.startsWith("file://") ? location : `file://${location}`;
      const completion = { localUri, destination: location, bytesDownloaded, bytesTotal, bytesPerSecond: 0 };
      const directoryUri = settingsRef.current.downloadDirectoryUri;
      if (directoryUri) {
        updateDownload(record.taskId, { ...completion, status: "copying", error: undefined });
        void copyToSafDirectory(localUri, directoryUri, record.file.name.split("/").pop() ?? `${record.movie.identifier}.mp4`, bytesDownloaded || record.file.bytes, record.file.format)
          .then((sharedCopyUri) => updateDownload(record.taskId, { ...completion, status: "completed", sharedCopyUri, error: undefined }))
          .catch(() => updateDownload(record.taskId, { ...completion, status: "completed", error: "Downloaded safely in app storage, but copying to the selected folder failed. Check folder access and available space." }));
      } else updateDownload(record.taskId, { ...completion, status: "completed", error: undefined });
      activeTasks.delete(record.taskId);
      void completeHandler(record.taskId);
    });
    task.error(({ error }) => {
      updateDownload(record.taskId, { status: "failed", error: error || "Download failed. Check your connection and retry.", bytesPerSecond: 0 });
      activeTasks.delete(record.taskId);
      void completeHandler(record.taskId);
    });
    return task;
  }, [updateDownload]);

  const startRecord = useCallback(async (record: DownloadRecord, allowedOverMetered: boolean) => {
    const network = await NetInfo.getNetworkStateAsync();
    if (!network.isConnected) throw new Error("You are offline. Reconnect to the internet before downloading this film.");
    if (!allowedOverMetered && network.type !== NetInfo.NetworkStateType.WIFI) throw new Error("Wi-Fi only is enabled. Connect to Wi-Fi before downloading this film.");
    if (record.file.bytes > 0) {
      const freeBytes = await FileSystem.getFreeDiskStorageAsync();
      if (freeBytes < record.file.bytes) throw new Error("Not enough free storage for this film. Free space and try again.");
    }
    const old = activeTasks.get(record.taskId);
    if (old) { try { await old.stop(); } catch { /* Task already completed or detached. */ } }
    const destination = `${directories.documents}/${sanitizeFilename(record.movie.identifier)}__${sanitizeFilename(record.file.name.split("/").pop() ?? "movie.mp4")}`;
    const nextRecord = { ...record, destination, localUri: undefined, status: "queued" as const, bytesDownloaded: 0, bytesTotal: record.file.bytes, bytesPerSecond: 0, error: undefined, updatedAt: Date.now() };
    persistDownloads([nextRecord, ...downloads.filter((item) => item.taskId !== record.taskId)]);
    const metadata = { moviebox: true, identifier: record.movie.identifier, title: record.movie.title, filename: record.file.name, fileFormat: record.file.format ?? "video", fileSize: record.file.bytes, destination };
    const task = createDownloadTask({ id: record.taskId, url: record.file.downloadUrl, destination, metadata, isAllowedOverMetered: allowedOverMetered, isAllowedOverRoaming: false, notificationTitle: record.movie.title });
    bindTask(task, nextRecord).start();
    await AsyncStorage.setItem(TASK_META_KEY, JSON.stringify({ [record.taskId]: metadata }));
  }, [bindTask, downloads, persistDownloads]);

  useEffect(() => {
    let mounted = true;
    (async () => {
      const [savedFavorites, savedDownloads, savedSettings] = await Promise.all([loadFavorites(), loadDownloads(), loadSettings()]);
      if (!mounted) return;
      setFavorites(savedFavorites);
      setDownloads(savedDownloads);
      setSettings(savedSettings);
      settingsRef.current = savedSettings;
      if (Platform.OS !== "web") {
        try {
          setConfig({ showNotificationsEnabled: true, showCompletionNotification: false, showCancelAction: false, progressInterval: 500, progressMinBytes: 64 * 1024 });
          const extantTasks = await getExistingDownloadTasks();
          if (!mounted) return;
          for (const task of extantTasks) {
            const taskMeta = task.tryParseJson(task.metadata) as Record<string, unknown> | null;
            const id = task.id;
            const oldRecord = savedDownloads.find((entry) => entry.taskId === id);
            if (oldRecord && taskMeta?.moviebox) {
              bindTask(task, oldRecord);
              const completedUri = oldRecord.localUri ?? (task.state === "DONE" && oldRecord.destination ? (oldRecord.destination.startsWith("file://") ? oldRecord.destination : `file://${oldRecord.destination}`) : undefined);
              updateDownload(id, { status: task.state === "PAUSED" ? "paused" : task.state === "DONE" ? "completed" : "downloading", bytesDownloaded: task.bytesDownloaded, bytesTotal: task.bytesTotal, localUri: completedUri });
            }
          }
          const liveIds = new Set(extantTasks.map((task) => task.id));
          const recovered = savedDownloads.map((record) => record.status === "copying"
            ? { ...record, status: "completed" as const, error: "The selected-folder copy was interrupted. The private offline copy is still available.", bytesPerSecond: 0 }
            : (record.status === "downloading" || record.status === "queued") && !liveIds.has(record.taskId)
              ? { ...record, status: "failed" as const, error: "Transfer stopped when Android closed it. Tap Retry to continue.", bytesPerSecond: 0 }
              : record);
          if (mounted) persistDownloads(recovered);
        } catch {
          // Expo Web preview does not expose Android's background transfer module.
        }
      }
      if (mounted) setReady(true);
    })();
    return () => { mounted = false; };
  }, [bindTask, persistDownloads, updateDownload]);

  const toggleFavorite = useCallback(async (movie: Movie) => {
    const next = favorites.some((entry) => entry.identifier === movie.identifier) ? favorites.filter((entry) => entry.identifier !== movie.identifier) : [movie, ...favorites];
    setFavorites(next);
    await saveFavorites(next);
  }, [favorites]);
  const isFavorite = useCallback((identifier: string) => favorites.some((entry) => entry.identifier === identifier), [favorites]);

  const startDownload = useCallback(async (movie: Movie, file: MovieQuality) => {
    if (Platform.OS === "web") throw new Error("Native background downloads are only available in the Android app.");
    const permission = await Notifications.getPermissionsAsync();
    if (permission.status !== "granted") {
      const requested = await Notifications.requestPermissionsAsync();
      if (requested.status !== "granted") throw new Error("Allow notifications so Android can show download progress.");
    }
    await Notifications.setNotificationChannelAsync("ins4n3-downloads", { name: "INS4N3 downloads", importance: Notifications.AndroidImportance.LOW, enableVibrate: false, showBadge: false });
    const taskId = `mb-${movie.identifier}-${file.name}`.replace(/[^\w.-]/g, "-").slice(0, 170);
    const record: DownloadRecord = { taskId, movie, file, destination: "", status: "queued", bytesDownloaded: 0, bytesTotal: file.bytes, bytesPerSecond: 0, updatedAt: Date.now() };
    await startRecord(record, !settings.wifiOnly);
  }, [settings.wifiOnly, startRecord]);

  const pauseDownload = useCallback(async (taskId: string) => { await activeTasks.get(taskId)?.pause(); updateDownload(taskId, { status: "paused", bytesPerSecond: 0 }); }, [updateDownload]);
  const resumeDownload = useCallback(async (taskId: string) => {
    const record = downloads.find((entry) => entry.taskId === taskId);
    if (!record) return;
    const network = await NetInfo.getNetworkStateAsync();
    if (!network.isConnected) throw new Error("You are offline. Reconnect to the internet before resuming this download.");
    if (settings.wifiOnly && network.type !== NetInfo.NetworkStateType.WIFI) throw new Error("Wi-Fi only is enabled. Connect to Wi-Fi before resuming.");
    const task = activeTasks.get(taskId);
    if (task) { await task.resume(); updateDownload(taskId, { status: "downloading", error: undefined }); }
    else await startRecord(record, !settings.wifiOnly);
  }, [downloads, settings.wifiOnly, startRecord, updateDownload]);
  const cancelDownload = useCallback(async (taskId: string) => {
    const task = activeTasks.get(taskId);
    if (task) await task.stop();
    activeTasks.delete(taskId);
    updateDownload(taskId, { status: "cancelled", bytesPerSecond: 0 });
  }, [updateDownload]);
  const retryDownload = useCallback(async (taskId: string) => {
    const record = downloads.find((entry) => entry.taskId === taskId);
    if (record) await startRecord(record, !settings.wifiOnly);
  }, [downloads, settings.wifiOnly, startRecord]);
  const deleteDownload = useCallback(async (taskId: string) => {
    const task = activeTasks.get(taskId);
    if (task) { try { await task.stop(); } catch { /* Already stopped. */ } activeTasks.delete(taskId); }
    const record = downloads.find((entry) => entry.taskId === taskId);
    if (record?.destination) { try { await FileSystem.deleteAsync(record.localUri ?? (record.destination.startsWith("file://") ? record.destination : `file://${record.destination}`), { idempotent: true }); } catch { /* It may be a partial or already removed file. */ } }
    if (record?.sharedCopyUri) { try { await FileSystem.StorageAccessFramework.deleteAsync(record.sharedCopyUri, { idempotent: true }); } catch { /* Shared folder access may have been revoked. */ } }
    const next = downloads.filter((entry) => entry.taskId !== taskId);
    persistDownloads(next);
  }, [downloads, persistDownloads]);

  const setWifiOnly = useCallback(async (enabled: boolean) => { const next = { ...settings, wifiOnly: enabled }; setSettings(next); await saveSettings(next); }, [settings]);
  const setDownloadDirectoryLabel = useCallback(async (label: string, uri?: string) => {
    const next = { ...settings, downloadDirectoryLabel: label, downloadDirectoryUri: uri };
    settingsRef.current = next;
    setSettings(next);
    await saveSettings(next);
  }, [settings]);
  const clearCache = useCallback(() => clearMovieCache(), []);

  const value = useMemo<ContextValue>(() => ({ favorites, downloads, settings, ready, toggleFavorite, isFavorite, startDownload, pauseDownload, resumeDownload, cancelDownload, retryDownload, deleteDownload, setWifiOnly, setDownloadDirectoryLabel, clearCache }), [favorites, downloads, settings, ready, toggleFavorite, isFavorite, startDownload, pauseDownload, resumeDownload, cancelDownload, retryDownload, deleteDownload, setWifiOnly, setDownloadDirectoryLabel, clearCache]);
  return <MovieBoxContext.Provider value={value}>{children}</MovieBoxContext.Provider>;
}

export function useMovieBox(): ContextValue {
  const value = useContext(MovieBoxContext);
  if (!value) throw new Error("useMovieBox must be used within MovieBoxProvider");
  return value;
}
