const fs = require("node:fs");
const path = require("node:path");
const { withDangerousMod } = require("expo/config-plugins");

const managerRelative = "node_modules/@kesha-antonov/react-native-background-downloader/android/src/main/java/com/kesha_antonov/uidt/UIDTNotificationManager.kt";
const serviceRelative = "node_modules/@kesha-antonov/react-native-background-downloader/android/src/main/java/com/kesha_antonov/ResumableDownloadService.kt";

function readRequired(projectRoot, relativePath) {
  const filePath = path.join(projectRoot, relativePath);
  if (!fs.existsSync(filePath)) throw new Error(`INS4N3 notification icon patch: expected downloader source was not found: ${relativePath}`);
  return { filePath, source: fs.readFileSync(filePath, "utf8") };
}

function withDownloaderNotificationIcon(config) {
  return withDangerousMod(config, ["android", async (modConfig) => {
    const projectRoot = modConfig.modRequest.projectRoot;
    const manager = readRequired(projectRoot, managerRelative);
    if (!manager.source.includes("INS4N3 notification icon patch")) {
      let source = manager.source;
      source = source.replaceAll("android.R.drawable.stat_sys_download_done", "ins4n3NotificationIcon(context)");
      source = source.replaceAll("android.R.drawable.stat_sys_download", "ins4n3NotificationIcon(context)");
      if (source === manager.source) throw new Error("INS4N3 notification icon patch: downloader notification call sites changed; review the native dependency before building.");
      source += `\n\n// INS4N3 notification icon patch: use expo-notifications' generated drawable for every transfer state.\nprivate fun ins4n3NotificationIcon(context: android.content.Context): Int {\n    val icon = context.resources.getIdentifier("notification_icon", "drawable", context.packageName)\n    return if (icon != 0) icon else android.R.drawable.stat_sys_download\n}\n`;
      fs.writeFileSync(manager.filePath, source);
    }

    const service = readRequired(projectRoot, serviceRelative);
    if (!service.source.includes("INS4N3 notification icon patch")) {
      const pattern = /val icon = if \(runningCount > 0\) \{\s*android\.R\.drawable\.stat_sys_download\s*\} else \{\s*android\.R\.drawable\.stat_sys_download_done\s*\}/;
      if (!pattern.test(service.source)) throw new Error("INS4N3 notification icon patch: foreground-service icon block changed; review the native dependency before building.");
      const replacement = `// INS4N3 notification icon patch: use the same branded drawable in the foreground service.\n    val appNotificationIcon = resources.getIdentifier("notification_icon", "drawable", packageName)\n    val icon = if (appNotificationIcon != 0) appNotificationIcon else android.R.drawable.stat_sys_download`;
      fs.writeFileSync(service.filePath, service.source.replace(pattern, replacement));
    }
    return modConfig;
  }]);
}

module.exports = withDownloaderNotificationIcon;
