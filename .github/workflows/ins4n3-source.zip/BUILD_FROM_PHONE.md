# Build the INS4N3 Android APK from a phone

This project is an Expo Android app. GitHub Actions creates the Android project, signs a release APK, checks the APK signature, and saves the APK as a downloadable workflow artifact. The workflow has not been run yet, so no APK is included in this source package.

## 1. Create a GitHub repository

On your phone, open [github.com](https://github.com) in the GitHub app or a browser and sign in. Create a new repository named `ins4n3-android`. Choose **Private** if you do not want the source and branding to be public. A public repository can use GitHub Actions standard runners without charge, while private repositories use the Actions minutes/storage included with your account and may incur charges after the applicable quota. Check your account’s Actions usage and billing limits before running a private-repository build. See [GitHub Actions billing](https://docs.github.com/en/actions/concepts/billing-and-usage).

Do not initialize the new repository with a README, license, or `.gitignore`; the source ZIP is the project payload.

## 2. Upload the project ZIP

Download `ins4n3-source.zip` from this delivery to your phone. In the repository, use **Add file → Upload files** and upload that ZIP at the repository root, then commit it to the default branch. The workflow knows how to unpack a root-level file named exactly `ins4n3-source.zip`.

The ZIP includes the app code, logo and Android icon assets, Expo configuration, lockfile, workflow, and this guide. It does not include generated Android/iOS folders, installed dependencies, environment files, signing keys, or secrets.

## 3. Add the workflow to the repository

GitHub only activates Actions workflows placed under `.github/workflows/`; a workflow file inside the source ZIP is not active until it is added at that repository path. On GitHub, choose **Add file → Create new file**. Enter this path as the filename:

```text
.github/workflows/build.yml
```

Open the separate `build.yml` file from this delivery, copy all its contents, paste them into GitHub’s editor, and commit the new file to the default branch. If the mobile editor does not allow creating nested folders, use the browser’s **Desktop site** option and retry.

## 4. Run the build

Open the repository’s **Actions** tab, select **Build signed INS4N3 APK**, choose **Run workflow**, keep the default branch selected, and confirm **Run workflow**. Open the new run and wait for all steps to finish successfully. The build may take several minutes while GitHub installs Android tooling and Gradle dependencies.

If the workflow fails, open the red failed step and its log. The build uses the project lockfile and generates native Android files during the run; you do not need a computer or a local Android build environment.

## 5. Download and install the APK

When the run succeeds, open its summary page and scroll to **Artifacts**. Download the `INS4N3-v1.0.0-run-…` artifact. GitHub downloads workflow artifacts as a ZIP; extract it on your phone to get the `.apk` file. Open the APK and allow your browser or file manager to install apps from that source if Android asks. Then confirm **Install**.

The APK package ID remains `space.manus.moviebox.t003148019780397`. Android generally treats a different signing key as a different app identity for updates. The default workflow creates a fresh temporary signing key each run, so its APK is signed and installable, but a later build will not be able to update that installation in place. Uninstalling first may be required, and uninstalling can erase the app’s local data. The workflow’s uploaded APK artifact is retained for 14 days.

## Optional: keep one signing identity for future updates

For repeat builds that should update the existing installation, create and securely back up your own PKCS#12 keystore, then add four repository Actions secrets under **Settings → Secrets and variables → Actions → New repository secret**:

- `ANDROID_KEYSTORE_BASE64`: the keystore file encoded as one uninterrupted Base64 string.
- `ANDROID_KEYSTORE_PASSWORD`: its store password.
- `ANDROID_KEY_ALIAS`: the alias in that keystore.
- `ANDROID_KEY_PASSWORD`: the key password.

A phone-only way to create the keystore is to use Termux from its official distribution source, install Java and core utilities, and run `keytool` to create a PKCS#12 keystore. For example, replace both occurrences of `REPLACE_WITH_A_LONG_UNIQUE_PASSWORD` with a unique password and keep it in a password manager:

```sh
pkg update
pkg install openjdk-17 coreutils
keytool -genkeypair -v \
  -keystore ins4n3-release.p12 -storetype PKCS12 \
  -storepass 'REPLACE_WITH_A_LONG_UNIQUE_PASSWORD' \
  -keypass 'REPLACE_WITH_A_LONG_UNIQUE_PASSWORD' \
  -alias ins4n3 -keyalg RSA -keysize 2048 -validity 10000 \
  -dname 'CN=INS4N3, OU=Mobile, O=INS4N3, C=US'
base64 ins4n3-release.p12 | tr -d '\n'
```

Copy the Base64 output directly into the `ANDROID_KEYSTORE_BASE64` secret; do not put it in the repository or send it in chat. Add the other three values as the matching secrets. The passwords and keystore must be backed up securely: losing the original signing key prevents updates signed with that key. If all four secrets are absent, the workflow uses a one-run key; if only some are set, it stops rather than silently changing signing mode. Never use a public repository for signing secrets, and never share or commit the keystore.

GitHub’s [Actions secrets documentation](https://docs.github.com/en/actions/security-guides/using-secrets-in-github-actions) explains repository secrets. Android’s [app signing documentation](https://developer.android.com/studio/publish/app-signing) explains why the signing key must be preserved for updates. Termux installation guidance is available from [Termux](https://termux.dev/en/).

## What is and is not verified

The source project’s TypeScript checks, lint, unit tests, and Expo web export passed previously. An Expo Android prebuild was also generated to verify the workflow’s native signing patch; no APK build or Android-device test has been performed. This package does not claim that search, quality selection, downloading, or offline playback have been validated on a physical Android phone. Run the workflow and test the installed app on your device before relying on it.

## References

- [GitHub Actions billing and usage](https://docs.github.com/en/actions/concepts/billing-and-usage)
- [GitHub Actions secrets](https://docs.github.com/en/actions/security-guides/using-secrets-in-github-actions)
- [Android app signing](https://developer.android.com/studio/publish/app-signing)
- [Termux](https://termux.dev/en/)
