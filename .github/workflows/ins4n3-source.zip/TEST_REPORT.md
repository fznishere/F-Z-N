# INS4N3 test report

**Date:** 2026-11-21
**App:** INS4N3
**Project:** `/home/ubuntu/moviebox`
**Package ID:** `space.manus.moviebox.t003148019780397`
**Version:** `1.0.0`

## Checks completed

- `pnpm check` — passed (TypeScript).
- `pnpm test` — passed: 31 tests passed; 1 test skipped. Archive client tests cover licensing filters, query construction, exact lookup, pagination, video eligibility, quality ranking, and size formatting.
- `pnpm lint` — passed.
- `expo export --platform web` — passed; 15 static routes bundled. This is a web-bundle sanity check, not Android verification.
- Expo config inspection — passed: visible app name `INS4N3`, version `1.0.0`, package ID `space.manus.moviebox.t003148019780397`, and notification icon are configured; `INTERNET`, `POST_NOTIFICATIONS`, and `WRITE_SETTINGS` are present, while broad legacy external-storage permissions are blocked.
- Android prebuild — passed with `expo prebuild --platform android --no-install`: generated native manifest/resources, including notification icons at five density sizes; the custom downloader patch replaced its small notification icons with the Expo `notification_icon` resource for transfer and foreground-service notifications. This was a prebuild/config check only; no Gradle build or install was run. The temporary generated `android/` directory was removed to preserve the managed Expo workflow.
- Supplied portrait branding — derived icon, adaptive-icon, splash, and notification resources are configured. The original attachment was not reopened.
- Live Internet Archive probe — passed at the API/media-endpoint level: a search returned 5 results; item metadata exposed 2 video qualities; the best-ranked MP4 media endpoint returned HTTP 200 and `video/mp4`. This did not download the movie into the app or test playback.

## Not verified / not delivered

No Android device run was available. In-app search, quality selector, actual download, offline playback, background notification/progress, pause/resume/cancel, SAF folder selection and copying, storage-full handling, delete, streaming, gestures, and restart recovery remain unverified on Android. No signed APK has been generated or installed, so APK size and signing status are not available.

A GitHub Actions release workflow is included at `.github/workflows/build.yml` as the phone-friendly build route. Its YAML was validated, and its signing patch was tested against fresh Expo prebuild output. The workflow itself has not been run, so no APK has been generated or installed. Do not treat prebuild or web export as an APK; the Android app flows listed above remain unverified on a device.
