import { useEffect, useState } from "react";
import { Animated, Easing, Image, StyleSheet, Text, View } from "react-native";

export function BrandSplash({ onComplete }: { onComplete: () => void }) {
  const [veil] = useState(() => new Animated.Value(1));
  const [logoOpacity] = useState(() => new Animated.Value(0));
  const [logoScale] = useState(() => new Animated.Value(0.92));
  const [copyOpacity] = useState(() => new Animated.Value(0));
  const [glowOpacity] = useState(() => new Animated.Value(0));

  useEffect(() => {
    const animation = Animated.sequence([
      Animated.parallel([
        Animated.timing(logoOpacity, { toValue: 1, duration: 720, easing: Easing.out(Easing.cubic), useNativeDriver: true }),
        Animated.spring(logoScale, { toValue: 1, speed: 13, bounciness: 4, useNativeDriver: true }),
        Animated.timing(glowOpacity, { toValue: 0.72, duration: 900, easing: Easing.out(Easing.quad), useNativeDriver: true }),
      ]),
      Animated.timing(copyOpacity, { toValue: 1, duration: 420, easing: Easing.out(Easing.cubic), useNativeDriver: true }),
      Animated.delay(1150),
      Animated.timing(veil, { toValue: 0, duration: 360, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
    ]);
    animation.start(({ finished }) => { if (finished) onComplete(); });
    return () => animation.stop();
  }, [copyOpacity, glowOpacity, logoOpacity, logoScale, onComplete, veil]);

  return <Animated.View pointerEvents="auto" style={[StyleSheet.absoluteFill, styles.overlay, { opacity: veil }]}>
    <View style={styles.center}>
      <Animated.View style={[styles.halo, { opacity: glowOpacity, transform: [{ scale: logoScale }] }]} />
      <Animated.View style={[styles.logoFrame, { opacity: logoOpacity, transform: [{ scale: logoScale }] }]}>
        <Image source={require("../assets/images/splash-icon.png")} style={styles.logo} resizeMode="cover" />
      </Animated.View>
      <Animated.View style={[styles.wordmark, { opacity: copyOpacity }]}>
        <Text style={styles.title}>I N S 4 N 3</Text>
        <Text style={styles.powered}>Powered by <Text style={styles.brand}>INS4N3</Text></Text>
      </Animated.View>
    </View>
  </Animated.View>;
}

const styles = StyleSheet.create({
  overlay: { zIndex: 1000, elevation: 1000, backgroundColor: "#05050A", alignItems: "center", justifyContent: "center" },
  center: { alignItems: "center", justifyContent: "center" },
  halo: { position: "absolute", width: 190, height: 190, borderRadius: 50, backgroundColor: "#00F0FF", shadowColor: "#00F0FF", shadowOpacity: 0.6, shadowRadius: 36, elevation: 20 },
  logoFrame: { width: 148, height: 148, borderRadius: 34, overflow: "hidden", borderWidth: 1, borderColor: "#00F0FF", backgroundColor: "#0D0D16", shadowColor: "#00F0FF", shadowOpacity: 0.5, shadowRadius: 22, shadowOffset: { width: 0, height: 0 }, elevation: 16 },
  logo: { width: "100%", height: "100%" },
  wordmark: { alignItems: "center", marginTop: 27 },
  title: { color: "#F4F4FA", fontSize: 18, fontWeight: "900", letterSpacing: 4.2 },
  powered: { color: "#9292A5", fontSize: 11, fontWeight: "600", letterSpacing: 1.6, marginTop: 10 },
  brand: { color: "#FF2BD6", fontWeight: "900" },
});
