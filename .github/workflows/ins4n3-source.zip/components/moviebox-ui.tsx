import { Ionicons } from "@expo/vector-icons";
import { Image } from "expo-image";
import { useState } from "react";
import { Pressable, ScrollView, StyleSheet, Text, TextInput, View, type TextInputProps, type ViewStyle } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { posterUrl } from "@/lib/archive";
import type { Movie } from "@/lib/moviebox/types";

export const C = {
  bg: "#05050A",
  card: "#0D0D16",
  raised: "#141421",
  cyan: "#00F0FF",
  magenta: "#FF2BD6",
  text: "#F4F4FA",
  muted: "#9292A5",
  dim: "#666677",
  line: "#252536",
  green: "#65F5B5",
  red: "#FF6688",
};

export function Page({ children, style }: { children: React.ReactNode; style?: ViewStyle }) {
  return <SafeAreaView edges={["top", "left", "right"]} style={[styles.page, style]}>{children}</SafeAreaView>;
}

export function ScrollPage({ children, contentContainerStyle }: { children: React.ReactNode; contentContainerStyle?: ViewStyle }) {
  return <Page><ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={[styles.scroll, contentContainerStyle]}>{children}</ScrollView></Page>;
}

export function BrandMark({ size = 35 }: { size?: number }) {
  return <Image source={require("../assets/images/icon.png")} contentFit="cover" transition={160} style={[styles.brand, { width: size, height: size, borderRadius: size * 0.29, borderWidth: 1, borderColor: C.cyan }]} />;
}

export function TopBar({ title, subtitle, right, onBack }: { title: string; subtitle?: string; right?: React.ReactNode; onBack?: () => void }) {
  return <View style={styles.topBar}>{onBack ? <Pressable onPress={onBack} hitSlop={10} style={styles.back}><Ionicons name="chevron-back" size={24} color={C.text} /></Pressable> : null}<View style={{ flex: 1 }}><Text style={styles.pageTitle}>{title}</Text>{subtitle ? <Text style={styles.subTitle}>{subtitle}</Text> : null}</View>{right}</View>;
}

export function SectionTitle({ title, action, onAction }: { title: string; action?: string; onAction?: () => void }) {
  return <View style={styles.sectionRow}><Text style={styles.sectionTitle}>{title}</Text>{action ? <Pressable onPress={onAction}><Text style={styles.sectionAction}>{action}</Text></Pressable> : null}</View>;
}

export function SearchField({ value, onChangeText, onSubmitEditing, placeholder = "Search public-domain movies", autoFocus = false }: Pick<TextInputProps, "value" | "onChangeText" | "onSubmitEditing" | "placeholder" | "autoFocus">) {
  return <View style={styles.searchField}><Ionicons name="search" size={19} color={C.cyan} /><TextInput value={value} onChangeText={onChangeText} onSubmitEditing={onSubmitEditing} returnKeyType="search" placeholder={placeholder} placeholderTextColor={C.dim} autoFocus={autoFocus} style={styles.searchInput} selectionColor={C.cyan} /></View>;
}

export function NeonButton({ title, onPress, icon, secondary = false, disabled = false, style }: { title: string; onPress: () => void; icon?: keyof typeof Ionicons.glyphMap; secondary?: boolean; disabled?: boolean; style?: ViewStyle }) {
  return <Pressable onPress={onPress} disabled={disabled} style={({ pressed }) => [styles.neonButton, secondary && styles.neonButtonSecondary, disabled && styles.disabled, pressed && !disabled && styles.pressed, style]}>{icon ? <Ionicons name={icon} size={18} color={secondary ? C.cyan : C.bg} /> : null}<Text style={[styles.neonButtonText, secondary && { color: C.cyan }]}>{title}</Text></Pressable>;
}

export function CategoryChip({ label, selected, onPress }: { label: string; selected: boolean; onPress: () => void }) {
  return <Pressable onPress={onPress} style={[styles.chip, selected && styles.chipSelected]}><Text style={[styles.chipText, selected && styles.chipTextSelected]}>{label}</Text></Pressable>;
}

export function MoviePosterCard({ movie, onPress, favorite, onToggleFavorite }: { movie: Movie; onPress: () => void; favorite?: boolean; onToggleFavorite?: () => void }) {
  const [broken, setBroken] = useState(false);
  return <Pressable onPress={onPress} style={({ pressed }) => [styles.posterCard, pressed && { opacity: 0.83, transform: [{ scale: 0.985 }] }]}>
    <View style={styles.posterFrame}>{broken ? <View style={styles.posterFallback}><BrandMark size={34} /><Text numberOfLines={3} style={styles.fallbackTitle}>{movie.title}</Text></View> : <Image source={{ uri: posterUrl(movie.identifier) }} onError={() => setBroken(true)} contentFit="cover" transition={240} style={StyleSheet.absoluteFill} />}
      <View style={styles.posterShade} />
      {movie.year ? <View style={styles.yearPill}><Text style={styles.yearText}>{movie.year}</Text></View> : null}
      {onToggleFavorite ? <Pressable onPress={onToggleFavorite} hitSlop={10} style={styles.heart}><Ionicons name={favorite ? "heart" : "heart-outline"} size={19} color={favorite ? C.magenta : C.text} /></Pressable> : null}
    </View>
    <Text numberOfLines={2} style={styles.posterTitle}>{movie.title}</Text>
    <Text style={styles.posterCaption}>PUBLIC DOMAIN{movie.year ? `  ·  ${movie.year}` : ""}</Text>
  </Pressable>;
}

export function EmptyState({ icon = "film-outline", title, body, action, onAction }: { icon?: keyof typeof Ionicons.glyphMap; title: string; body: string; action?: string; onAction?: () => void }) {
  return <View style={styles.empty}><View style={styles.emptyIcon}><Ionicons name={icon} size={27} color={C.cyan} /></View><Text style={styles.emptyTitle}>{title}</Text><Text style={styles.emptyBody}>{body}</Text>{action && onAction ? <NeonButton title={action} onPress={onAction} secondary style={{ marginTop: 18 }} /> : null}</View>;
}

export function PoweredFooter() {
  return <View style={styles.footer}><View style={styles.footerLine} /><Text style={styles.footerText}>Powered by <Text style={styles.footerBrand}>INS4N3</Text></Text><View style={styles.footerLine} /></View>;
}

export function ErrorBanner({ message, onRetry }: { message: string; onRetry: () => void }) {
  return <View style={styles.errorBox}><Ionicons name="cloud-offline-outline" size={18} color={C.red} /><Text style={styles.errorText}>{message}</Text><Pressable onPress={onRetry}><Text style={styles.retryText}>Retry</Text></Pressable></View>;
}

const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: C.bg },
  scroll: { paddingBottom: 28 },
  brand: { justifyContent: "center", alignItems: "center", overflow: "hidden", shadowColor: C.cyan, shadowOpacity: 0.55, shadowRadius: 13, elevation: 8 },
  brandFill: { position: "absolute", top: 0, right: 0, bottom: 0, left: 0, backgroundColor: C.cyan, borderRadius: 20 },
  topBar: { flexDirection: "row", alignItems: "center", minHeight: 55, paddingHorizontal: 20, gap: 12 },
  back: { width: 35, height: 40, justifyContent: "center" },
  pageTitle: { color: C.text, fontSize: 25, fontWeight: "800", letterSpacing: 0.2 },
  subTitle: { color: C.muted, fontSize: 12, marginTop: 2, letterSpacing: 0.5 },
  sectionRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 24, marginBottom: 13 },
  sectionTitle: { color: C.text, fontSize: 18, fontWeight: "700", letterSpacing: 0.15 },
  sectionAction: { color: C.cyan, fontSize: 12, fontWeight: "700" },
  searchField: { height: 50, borderRadius: 15, borderWidth: 1, borderColor: "#24243A", backgroundColor: C.card, flexDirection: "row", alignItems: "center", paddingHorizontal: 15, gap: 11 },
  searchInput: { flex: 1, color: C.text, fontSize: 14, paddingVertical: 0 },
  neonButton: { height: 49, paddingHorizontal: 19, borderRadius: 15, backgroundColor: C.cyan, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 9, shadowColor: C.cyan, shadowOpacity: 0.28, shadowRadius: 12, shadowOffset: { width: 0, height: 0 }, elevation: 5 },
  neonButtonSecondary: { backgroundColor: "#101521", borderWidth: 1, borderColor: "#176370", shadowColor: C.cyan, shadowOpacity: 0.15 },
  neonButtonText: { color: C.bg, fontSize: 14, fontWeight: "800", letterSpacing: 0.3 },
  disabled: { opacity: 0.45 },
  pressed: { opacity: 0.82, transform: [{ scale: 0.985 }] },
  chip: { borderRadius: 24, borderWidth: 1, borderColor: C.line, paddingHorizontal: 15, paddingVertical: 9, marginRight: 8, backgroundColor: C.card },
  chipSelected: { borderColor: C.cyan, backgroundColor: "#062127", shadowColor: C.cyan, shadowOpacity: 0.18, shadowRadius: 8, elevation: 2 },
  chipText: { color: C.muted, fontSize: 12, fontWeight: "600" },
  chipTextSelected: { color: C.cyan },
  posterCard: { flex: 1, minWidth: 0, marginBottom: 18 },
  posterFrame: { height: 230, borderRadius: 16, overflow: "hidden", backgroundColor: C.raised, borderWidth: 1, borderColor: "#252536", position: "relative" },
  posterFallback: { flex: 1, alignItems: "center", justifyContent: "center", padding: 16, gap: 10, backgroundColor: "#11111B" },
  fallbackTitle: { color: C.text, fontSize: 12, fontWeight: "700", textAlign: "center" },
  posterShade: { position: "absolute", top: 0, right: 0, bottom: 0, left: 0, backgroundColor: "transparent", borderRadius: 15 },
  yearPill: { position: "absolute", top: 10, left: 10, borderRadius: 8, backgroundColor: "rgba(5,5,10,0.82)", borderWidth: 1, borderColor: "#353546", paddingHorizontal: 9, paddingVertical: 5 },
  yearText: { color: C.text, fontSize: 10, fontWeight: "700" },
  heart: { position: "absolute", top: 8, right: 8, width: 34, height: 34, borderRadius: 17, alignItems: "center", justifyContent: "center", backgroundColor: "rgba(5,5,10,0.74)" },
  posterTitle: { color: C.text, fontSize: 13, fontWeight: "700", lineHeight: 17, marginTop: 9, minHeight: 34 },
  posterCaption: { color: C.cyan, fontSize: 8, letterSpacing: 1.1, fontWeight: "800", marginTop: 4 },
  empty: { alignItems: "center", justifyContent: "center", paddingHorizontal: 35, paddingVertical: 52, minHeight: 250 },
  emptyIcon: { width: 55, height: 55, borderRadius: 18, backgroundColor: "#10141F", alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: "#173844", marginBottom: 15 },
  emptyTitle: { color: C.text, fontSize: 17, fontWeight: "800", textAlign: "center" },
  emptyBody: { color: C.muted, fontSize: 13, textAlign: "center", lineHeight: 19, marginTop: 7 },
  footer: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 13, paddingVertical: 24, marginTop: 2 },
  footerLine: { width: 31, height: 1, backgroundColor: "#28283A" },
  footerText: { color: C.dim, fontSize: 9, letterSpacing: 1.7, fontWeight: "700" },
  footerBrand: { color: C.magenta, fontWeight: "900" },
  errorBox: { marginHorizontal: 20, marginTop: 15, borderWidth: 1, borderColor: "#55283D", backgroundColor: "#1C0D18", borderRadius: 13, padding: 12, flexDirection: "row", alignItems: "center", gap: 8 },
  errorText: { color: C.text, flex: 1, fontSize: 12, lineHeight: 17 },
  retryText: { color: C.cyan, fontSize: 12, fontWeight: "800" },
} as const);
