# INS4N3 source notes

- Archive.org Advanced Search accepts URL-encoded Lucene queries and supports paginated JSON responses with field selection (`fl[]`, `rows`, `page`, `output=json`). INS4N3 also requests `licenseurl` so the client can enforce the requested legal restriction rather than treating collection membership alone as a license.
- The Metadata Read API returns item metadata and a `files` array. File entries can expose names, formats, sizes, and other media metadata; size must be treated as untrusted/missing data.
- INS4N3 accepts only explicit CC Public Domain Mark 1.0 and CC0 1.0 license URLs (HTTP/HTTPS variants), and re-checks metadata before exposing media choices. This is a product filter, not a legal guarantee about publicity, privacy, trademarks, or jurisdiction-specific restrictions.
- Native background downloads require an Expo config plugin and a native build; Expo Web checks cannot establish Android notification/service behavior. The initialized Expo project’s template directs Android APK/AAB creation through Dashboard and prohibits release builds inside the Sandbox.

## References

[1] https://archive.org/developers/index-apis.html "Internet Archive APIs"
[2] https://archive.org/advancedsearch.php "Internet Archive Advanced Search"
[3] https://archive.org/developers/md-read.html "Internet Archive Metadata Read API"
[4] https://creativecommons.org/publicdomain/mark/1.0/ "Creative Commons Public Domain Mark 1.0"
[5] https://creativecommons.org/publicdomain/zero/1.0/ "Creative Commons CC0 1.0 Universal"
[6] https://www.npmjs.com/package/%40kesha-antonov/react-native-background-downloader "React Native Background Downloader"
[7] https://docs.expo.dev/versions/latest/sdk/filesystem-legacy/ "Expo FileSystem Legacy"

[8] https://docs.expo.dev/versions/latest/sdk/brightness/ "Expo Brightness"

- Official Manus guidance says the APK action uses the connected personal Expo account and Expo cloud build services; the Help Center documents 15 Android builds per calendar month on Expo Free, resetting on the first of the next month. Dashboard build result is required before claiming an artifact.

[9] https://manus.im/features/app-publishing "Publish Apps to TestFlight and Google Play"
[10] https://help.manus.im/en/articles/16997172-why-do-i-see-expo-build-quota-exceeded-when-building-an-android-apk "Why do I see Expo build quota exceeded when building an Android APK?"
